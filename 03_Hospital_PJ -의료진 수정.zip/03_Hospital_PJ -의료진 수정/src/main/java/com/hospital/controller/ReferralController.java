package com.hospital.controller;

import com.hospital.service.ReferralService;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.ReferralCommentVO;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;
import com.hospital.vo.ReferralReplyVO;


import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/referral")
public class ReferralController {

    @Autowired
    private ReferralService referralService;

    // ✅ 협진 신청 폼 호출
    @GetMapping("/requestForm.do")
    public String showReferralRequestForm(@RequestParam("recordId") int recordId, Model model) {
        ReferralRequestVO requestVO = referralService.convertToReferralRequest(recordId);
        model.addAttribute("requestVO", requestVO);

        List<PartnerHospitalVO> hospitals = referralService.getAllPartnerHospitals();
        model.addAttribute("hospitals", hospitals);

        return "doctor/referral_request_form";
    }

    // ✅ 협진 요청 등록 처리
//    @PostMapping("/submitRequest.do")
//    public String submitReferralRequest(@ModelAttribute ReferralRequestVO requestVO,
//                                        HttpSession session) {
//        UserVO loginUser = (UserVO) session.getAttribute("loginUser");
//
//        if (loginUser == null) {
//            return "redirect:/user/loginForm.do";
//        }
//
//        requestVO.setDoctorId(loginUser.getUserId()); // ✅ 보내는 의사
//        // ✅ userId, hospitalId는 폼에서 선택된 값이 이미 들어옴 → set 안 해도 됨
//        requestVO.setStatus("접수");
//        
//        
//        requestVO.setUserId(loginUser.getUserId());
//        referralService.insertReferralRequest(requestVO);
//        return "redirect:/referral/history.do";
//    }
    @PostMapping("/submitRequest.do")
    public String submitReferralRequest(@ModelAttribute ReferralRequestVO requestVO,
                                        HttpSession session) {
        UserVO loginUser = (UserVO) session.getAttribute("loginUser");

        if (loginUser == null) {
            return "redirect:/user/loginForm.do";
        }

        requestVO.setDoctorId(loginUser.getUserId()); // 보내는 의사 ID
        requestVO.setStatus("접수"); // 상태 설정

        referralService.insertReferralRequest(requestVO); // 받는 의사 ID는 form에서 바인딩됨

        return "doctor/doctor_main";
    }
    
    

    // ✅ 병원 ID로 해당 병원의 의사 목록 조회 (AJAX 용)
    @GetMapping("/doctors.do")
    @ResponseBody
    public List<UserVO> getDoctorsByHospital(@RequestParam("hospitalId") int hospitalId) {
        return referralService.getDoctorsByHospital(hospitalId);
    }
    
    
 // ✅ 협진 요청 수신 목록 - 우리 병원에 들어온 요청들
    @GetMapping("/received.do")
    public String showReceivedReferrals(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        UserVO loginUser = (UserVO) session.getAttribute("loginUser");

        if (loginUser == null) {
            redirectAttributes.addFlashAttribute("error", "로그인이 필요합니다.");
            return "redirect:/user/loginForm.do";
        }

        int hospitalId = loginUser.getHospitalId();
        String userId = loginUser.getUserId();

        // 🔁 내가 보낸 것 + 우리 병원이 받은 것 모두 조회
        List<ReferralRequestVO> referrals = referralService.getVisibleReferrals(hospitalId, userId);
        model.addAttribute("requests", referrals);

        return "doctor/received_referrals"; // JSP는 그대로 사용
        
    }
    
    @GetMapping("detail.do")
    public String showReferralDetail(@RequestParam("requestId") int requestId,
                                     Model model,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        // 로그인 사용자 가져오기
        UserVO loginUser = (UserVO) session.getAttribute("loginUser");
        if (loginUser == null) {
            redirectAttributes.addFlashAttribute("error", "로그인이 필요합니다.");
            return "redirect:/user/loginForm.do";
        }

        // 1. 진료의뢰 상세 정보
        ReferralRequestVO request = referralService.getReferralRequestById(requestId);
        if (request == null) {
            redirectAttributes.addFlashAttribute("error", "해당 진료의뢰를 찾을 수 없습니다.");
            return "redirect:/referral/received.do";
        }

        // 2. 회신 내용 (있을 수도 있고 없을 수도 있음)
        ReferralReplyVO reply = referralService.getReplyByRequestId(requestId);

        // 3. 댓글 목록
        List<ReferralCommentVO> comments = referralService.getReferralCommentsByRequestId(requestId);

        // model 등록
        model.addAttribute("request", request);
        model.addAttribute("reply", reply);
        model.addAttribute("comments", comments);
        model.addAttribute("loginUser", loginUser);

        return "doctor/referral_detail";

    }
    
    
    @PostMapping("/addComment.do") //댓글달기
    public String addComment(@RequestParam("requestId") int requestId,
                             @RequestParam("commentText") String commentText,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        UserVO loginUser = (UserVO) session.getAttribute("loginUser");

        if (loginUser == null) {
            redirectAttributes.addFlashAttribute("error", "로그인이 필요합니다.");
            return "redirect:/user/loginForm.do";
        }

        ReferralCommentVO comment = new ReferralCommentVO();
        comment.setRequestId(requestId);
        comment.setDoctorId(loginUser.getUserId());
        comment.setCommentText(commentText);

        referralService.addComment(comment);

        return "redirect:/referral/detail.do?requestId=" + requestId;
    }

    
    @PostMapping("/updateComment.do")
    public String updateComment(@RequestParam("commentId") int commentId,
                                @RequestParam("requestId") int requestId,
                                @RequestParam("commentText") String commentText,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {

        UserVO loginUser = (UserVO) session.getAttribute("loginUser");
        if (loginUser == null) {
            redirectAttributes.addFlashAttribute("error", "로그인이 필요합니다.");
            return "redirect:/loginForm.do";
        }

        ReferralCommentVO comment = new ReferralCommentVO();
        comment.setCommentId(commentId);
        comment.setDoctorId(loginUser.getUserId());
        comment.setCommentText(commentText);

        referralService.updateComment(comment);

        return "redirect:/referral/detail.do?requestId=" + requestId;
    }

    @PostMapping("/deleteComment.do")
    public String deleteComment(@RequestParam("commentId") int commentId,
                                @RequestParam("requestId") int requestId,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {

        UserVO loginUser = (UserVO) session.getAttribute("loginUser");
        if (loginUser == null) {
            redirectAttributes.addFlashAttribute("error", "로그인이 필요합니다.");
            return "redirect:/loginForm.do";
        }

        referralService.deleteComment(commentId, loginUser.getUserId());

        return "redirect:/referral/detail.do?requestId=" + requestId;
    }

    
    
    
    
    
}
