package com.hospital.controller;

import com.hospital.service.DoctorScheduleService;
import com.hospital.service.DoctorService;
import com.hospital.service.UserService;
import com.hospital.vo.DepartmentVO;
import com.hospital.vo.DoctorScheduleVO;
import com.hospital.vo.PatientVO;
import com.hospital.vo.ReservationVO;
import com.hospital.vo.UserVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpSession;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Date;
import com.hospital.service.ReservationService;


@Controller
@RequestMapping("/doctors")
public class ReservationController {
	
	
	
	@Autowired
	private ReservationService reservationService;
	
	@GetMapping("/non-member-entry.do")
	public String showNonMemberEntryPage() {
	    return "patient/non_member_entry";
	}

	
	// 1. 회원 예약 조회
	// 1. 회원 예약 조회
	@GetMapping("/reservation/member/check")
	public String checkMemberReservation(HttpSession session, Model model) {
	    UserVO loginUser = (UserVO) session.getAttribute("loginUser");
	    if (loginUser == null) {
	        return "redirect:/login.do";
	    }

	    // 세션에서 patientNo 가져오기
	    Integer patientNo = (Integer) session.getAttribute("patientNo");
	    if (patientNo == null) {
	        // 로그인 당시 patientNo가 세션에 저장되지 않았다면 다시 조회
	        patientNo = reservationService.getPatientNoByUserId(loginUser.getUserId());
	        session.setAttribute("patientNo", patientNo);
	    }

	    List<ReservationVO> reservations = reservationService.getReservationsByPatientNo(patientNo);
	    model.addAttribute("reservations", reservations);
	    return "patient/reservation_edit";
	}

	// 2. 비회원 예약 조회
	@PostMapping("/reservation/nonmember/check")
	public String checkNonMemberReservation(@RequestParam("name") String name,
	                                        @RequestParam("ssn") String ssn,
	                                        Model model,
	                                        HttpSession session) {
	    int patientNo = reservationService.findExistingPatient(name, ssn);
	    
	    if (patientNo == 0) {
	        // 주민번호는 존재하지만 이름이 다르면
	        if (reservationService.isExistingSSNOnly(ssn) > 0) {
	            model.addAttribute("alertMessage", "입력한 이름과 주민번호가 일치하지 않습니다.");
	        } else {
	            model.addAttribute("alertMessage", "일치하는 환자 정보가 없습니다.");
	        }
	        return "patient/reservation_check";
	    }
	    
	    // ✅✅ 세션에 저장 추가
	    session.setAttribute("patientNo", patientNo);
	    session.setAttribute("patientName", name);
	    

	    // 2. patientNo로 예약 목록 조회
	    List<ReservationVO> reservations = reservationService.getReservationsByPatientNo(patientNo);
	    model.addAttribute("reservations", reservations);
	    model.addAttribute("patientNo", patientNo);
	    model.addAttribute("today", new java.sql.Date(System.currentTimeMillis()));
	    return "patient/reservation_edit";
	}



	@PostMapping("/nonmember/check.do")
	public String checkNonMemberInfo(@RequestParam String name,
	                                 @RequestParam String ssn,
	                                 @RequestParam String phone,
	                                 Model model) {
	    // 주민번호 유효성 검사
	    if (ssn == null || !ssn.matches("\\d{13}")) {
	        model.addAttribute("alertMessage", "주민등록번호는 13자리 숫자여야 합니다.");
	        return "patient/non_member_entry";
	    }

	    // 🔒 전화번호 유효성 검사
	    if (phone == null || !phone.matches("\\d{11}")) {
	        model.addAttribute("alertMessage", "전화번호는 11자리 숫자여야 합니다.");
	        return "patient/non_member_entry";
	    }
		
		// 1️⃣ 회원 여부 확인 → 로그인 유도
	    if (reservationService.isExistingMember(ssn) > 0) {
	        model.addAttribute("alertMessage", "회원입니다. 로그인 후 예약해주세요.");
	        return "patient/non_member_entry";
	    }

	    // 2️⃣ 기존 비회원 환자 존재 여부 확인 (이름 + 주민번호 일치)
	    int existingPatientNo = reservationService.findExistingPatient(name, ssn);
	    if (existingPatientNo > 0) {
	        model.addAttribute("patientNo", existingPatientNo);
	        return "forward:/doctors/reservation.do";
	    }

	    // 3️⃣ 주민번호는 존재하지만 이름이 다르면 (이름+주민번호 불일치)
	    if (reservationService.isExistingSSNOnly(ssn) > 0) {
	        model.addAttribute("alertMessage", "입력한 이름과 주민번호가 일치하지 않습니다.");
	        return "patient/non_member_entry";
	    }

	    // 4️⃣ 신규 비회원 등록
	    int newPatientNo = reservationService.registerNonMember(name, ssn, phone);
	    model.addAttribute("patientNo", newPatientNo);
	    return "forward:/doctors/reservation.do";
	}

	
	
	
	// 수정 폼 이동
	@GetMapping("/reservation/editForm.do")
	public String showEditForm(HttpSession session, Model model) {
	    PatientVO loginUser = (PatientVO) session.getAttribute("loginUser");  // ✔ 수정
	    if (loginUser == null) {
	        return "redirect:/login.do";
	    }

	    Integer patientNo = (Integer) session.getAttribute("patientNo");
	    if (patientNo == null) {
	        patientNo = reservationService.getPatientNoByUserId(loginUser.getPatientUserId());
	        session.setAttribute("patientNo", patientNo);
	    }

	    List<ReservationVO> reservations = reservationService.getReservationsByPatientNo(patientNo);
	    if (reservations == null || reservations.isEmpty()) {
	        model.addAttribute("alertMessage", "예약 정보가 없습니다.");
	        return "patient/reservation_edit";
	    }
	    
	    
	    model.addAttribute("today", new java.sql.Date(System.currentTimeMillis()));

	    model.addAttribute("reservations", reservations);
	    return "patient/reservation_edit";
	}
	

	// 수정 처리
	@PostMapping("/reservation/update.do")
	public String updateReservation(@ModelAttribute ReservationVO reservation) {
	    reservationService.updateReservation(reservation);
	    return "redirect:/doctors/reservation/member/check";
	}
	
	
	@PostMapping("/reservation/editAndRedirect.do")
	public String cancelAndRedirect(@RequestParam("reservationId") int reservationId,
	                                @RequestParam("patientNo") int patientNo,
	                                @RequestParam("department") String department,
	                                @RequestParam("doctorId") String doctorId) throws UnsupportedEncodingException {
	    reservationService.cancelReservation(reservationId);

	    String encodedDept = URLEncoder.encode(department, "UTF-8");
	    String encodedDoctor = URLEncoder.encode(doctorId, "UTF-8");

	    return "redirect:/doctors/reservation.do?deptId=" + encodedDept +
	           "&doctorName=" + encodedDoctor +
	           "&patientNo=" + patientNo;
	}
	
	
	
	// 삭제 처리
	@PostMapping("/reservation/delete.do")
	public String cancelReservation(@RequestParam("reservationId") int reservationId,
	                                @RequestParam("type") String type,
	                                HttpSession session,
	                                Model model) {
	    reservationService.cancelReservation(reservationId);
	    
	    
	    if ("member".equals(type)) {
	        Integer patientNo = (Integer) session.getAttribute("patientNo");
	        if (patientNo != null) {
	            List<ReservationVO> reservations = reservationService.getReservationsByPatientNo(patientNo);
	            model.addAttribute("reservations", reservations);
	        }
	        // ✅ 메시지 저장
	        session.setAttribute("alertMessage", "예약이 취소되었습니다.");
	        return "patient/reservation_edit";

	    } else {
	        Integer patientNo = (Integer) session.getAttribute("patientNo");
	        String name = (String) session.getAttribute("patientName");

	        if (patientNo != null && name != null) {
	            List<ReservationVO> reservations = reservationService.getReservationsForNonMember(name, patientNo);
	            model.addAttribute("reservations", reservations);
	            model.addAttribute("patientNo", patientNo);
	            model.addAttribute("today", new java.sql.Date(System.currentTimeMillis()));
	        }

	        // ✅ 메시지 저장
	        session.setAttribute("alertMessage", "예약이 취소되었습니다.");
	        return "patient/reservation_edit";
	    }
	}



	
	@PostMapping("/reservation/save.do")
	public String saveReservation(@RequestParam("patientNo") int patientNo,
	                              @RequestParam("doctorId") String doctorId,
	                              @RequestParam("department") String department,
	                              @RequestParam("reservationDate") String reservationDateStr,
	                              @RequestParam("scheduleId") int scheduleId,
	                              @RequestParam("scheduleTime") String scheduleTime,
	                              @RequestParam(value = "questionnaireContent", required = false) String questionnaireContent) {

	    // ✅ doctorId 누락 방지
	    if (doctorId == null || doctorId.trim().isEmpty()) {
	        throw new IllegalArgumentException("의사 정보가 누락되었습니다.");
	    }

	    ReservationVO vo = new ReservationVO();
	    vo.setPatientNo(patientNo);
	    vo.setDoctorId(doctorId);
	    vo.setDepartment(department);
	    vo.setReservationDate(Date.valueOf(reservationDateStr));
	    vo.setStatus("확정");
	    vo.setScheduleId(scheduleId);
	    vo.setScheduleTime(scheduleTime);

	    reservationService.saveReservationWithQuestionnaire(vo, questionnaireContent);

	    return "patient/reservation_success";
	}

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private UserService userService;
    
    @Autowired
    private DoctorScheduleService doctorScheduleService;

    // 진료 예약 페이지 이동 + 진료과 목록 전달
    @RequestMapping(value = "/reservation.do", method = {RequestMethod.GET, RequestMethod.POST})
//    @GetMapping("/reservation.do")
    public String showReservationPage(Model model,
                                      @RequestParam(value = "deptId", required = false) String deptId,
                                      @RequestParam(value = "doctorName", required = false) String doctorName,
                                      @RequestParam(value = "patientNo", required = false) Integer patientNo) {
        
    	
    	List<DoctorScheduleVO> scheduleList = doctorScheduleService.getScheduleByDoctorName(doctorName);

    	// 시간 필터링 로직
    	LocalDate today = LocalDate.now();
    	LocalTime now = LocalTime.now();
    	DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

    	List<DoctorScheduleVO> filteredList = new ArrayList<>();
    	for (DoctorScheduleVO schedule : scheduleList) {
    	    LocalDate scheduleDate = schedule.getScheduleDate()
    	        .toInstant()
    	        .atZone(ZoneId.systemDefault())
    	        .toLocalDate();

    	    LocalTime scheduleTime = LocalTime.parse(schedule.getScheduleTime(), timeFormatter);

    	    if (scheduleDate.isAfter(today)) {
    	        filteredList.add(schedule);
    	    } else if (scheduleDate.isEqual(today) && scheduleTime.isAfter(now)) {
    	        filteredList.add(schedule);
    	    }
    	}

    	// ✅ 중복 선언하지 말고 재할당만
    	scheduleList = filteredList;



    	
    	
    	
        // 👇 patientNo 전달
        if (patientNo != null) {
            model.addAttribute("patientNo", patientNo);
        }
        // 진료과 전체 목록 조회
        List<DepartmentVO> deptList = doctorService.getAllDepartments();
        model.addAttribute("deptList", deptList);
        model.addAttribute("selectedDeptId", deptId);
        model.addAttribute("selectedDoctorName", doctorName);
        
        // 진료과 선택 시 해당 진료과 의사 이름 목록 조회 (users 테이블 기준)
        if (deptId != null && !deptId.isEmpty()) {
            List<String> doctorNames = userService.getDoctorNamesByDeptId(deptId);
            model.addAttribute("doctorNames", doctorNames);
            
        }

        // 의사 이름 선택 시 해당 의사의 스케줄 조회 (AJAX 아님)
        if (doctorName != null && !doctorName.isEmpty()) {
            
        	  // 🔽 🔴 정확한 doctorId 조회 (중복 방지)
            String doctorId = reservationService.getDoctorIdByNameAndDepartment(doctorName, deptId);
            model.addAttribute("selectedDoctorId", doctorId);
        	
        	 // 1. 스케줄 조회
            scheduleList = doctorScheduleService.getScheduleByDoctorName(doctorName);
        	 // 2. 이미 예약된 schedule_id 목록 조회
            List<Integer> reservedIds = reservationService.getReservedScheduleIds();
         // 3. model에 전달
            model.addAttribute("scheduleList", scheduleList);
            model.addAttribute("reservedIds", reservedIds);

            // 4. 의사 ID 조회
//            String doctorId = userService.getDoctorIdByName(doctorName); // 이 메서드는 있어야 합니다
//            model.addAttribute("selectedDoctorId", doctorId);
         // 5. scheduleMap(JSON 변환용)
            Map<String, List<Map<String, Object>>> scheduleMap = new LinkedHashMap<String, List<Map<String, Object>>>();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            for (DoctorScheduleVO schedule : scheduleList) {
                String dateStr = sdf.format(schedule.getScheduleDate());

                List<Map<String, Object>> timeList = scheduleMap.get(dateStr);
                if (timeList == null) {
                    timeList = new ArrayList<Map<String, Object>>();
                    scheduleMap.put(dateStr, timeList);
                }

                
                Map<String, Object> timeEntry = new LinkedHashMap<String, Object>();
                timeEntry.put("id", schedule.getScheduleId());
                timeEntry.put("time", schedule.getScheduleTime());
                timeEntry.put("note", schedule.getNote());

                timeList.add(timeEntry);
            }

            // JSON 문자열 생성
            StringBuilder sb = new StringBuilder();
            sb.append("{");

            int i = 0;
            for (Map.Entry<String, List<Map<String, Object>>> entry : scheduleMap.entrySet()) {
                if (i++ > 0) sb.append(",");
                sb.append("\"").append(entry.getKey()).append("\":[");

                List<Map<String, Object>> timeEntries = entry.getValue();
                for (int j = 0; j < timeEntries.size(); j++) {
                    Map<String, Object> timeEntry = timeEntries.get(j);
                    if (j > 0) sb.append(",");
                    sb.append("{\"id\":").append(timeEntry.get("id")).append(",");
                    sb.append("\"time\":\"").append(timeEntry.get("time")).append("\",");
                    sb.append("\"note\":\"").append(timeEntry.get("note")).append("\"}"); // ✅ 요줄 추가
                }


                sb.append("]");
            }
            sb.append("}");

            model.addAttribute("scheduleJson", sb.toString());

        }
        return "patient/reservation"; // JSP로 이동
    }
    
    @GetMapping("/reservation/check.do")
    public String showReservationCheckPage() {
        return "patient/reservation_check";  // 폴더명 + 파일명 (확장자 없이)
    }
    

}