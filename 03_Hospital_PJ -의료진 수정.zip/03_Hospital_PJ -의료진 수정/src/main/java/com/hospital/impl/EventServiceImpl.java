package com.hospital.impl;

public class EventServiceImpl {

}
