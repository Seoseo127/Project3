package com.hospital.impl;

import com.hospital.dao.ReferralDAO;
import com.hospital.service.ReferralService;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;
import com.hospital.vo.ReferralReplyVO;
import com.hospital.vo.ReferralCommentVO;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReferralServiceImpl implements ReferralService {

    @Autowired
    private ReferralDAO referralDAO;

    @Override
    public ReferralRequestVO convertToReferralRequest(int recordId) {
        return referralDAO.convertToReferralRequest(recordId);
    }

    @Override
    public List<PartnerHospitalVO> getAllPartnerHospitals() {
        return referralDAO.getAllPartnerHospitals();
    }

    @Override
    public void insertReferralRequest(ReferralRequestVO requestVO) {
        referralDAO.insertReferralRequest(requestVO);
    }
    
    @Override
    public List<UserVO> getDoctorsByHospital(int hospitalId) {
        return referralDAO.getDoctorsByHospital(hospitalId);
    }
    
    @Override
    public List<ReferralRequestVO> getVisibleReferrals(int hospitalId, String userId) {
        return referralDAO.getVisibleReferrals(hospitalId, userId);
    }
    
    @Override
    public ReferralRequestVO getReferralRequestById(int requestId) {
        return referralDAO.getReferralRequestById(requestId);
    }

    @Override
    public ReferralReplyVO getReplyByRequestId(int requestId) {
        ReferralReplyVO reply = referralDAO.getReplyByRequestId(requestId);  // ✅ 먼저 가져오기

        if (reply != null && reply.getReplyContent() != null) {
            String clean = reply.getReplyContent().replaceAll("<[^>]*>", "");
            reply.setCleanReplyContent(clean);
        }

        return reply;  // ✅ 가공된 객체 반환
    }


    @Override
    public List<ReferralCommentVO> getReferralCommentsByRequestId(int requestId) {
        return referralDAO.getReferralCommentsByRequestId(requestId);
        
    }


    @Override
    public void addComment(ReferralCommentVO comment) {
        int nextId = referralDAO.getNextCommentId();
        comment.setCommentId(nextId);
        referralDAO.addComment(comment);
    }

    @Override
    public void updateComment(ReferralCommentVO commentVO) {
        referralDAO.updateComment(commentVO);
    }
    
    @Override
    public void deleteComment(int commentId, String userId) {
        referralDAO.deleteComment(commentId, userId);
    }

}

