package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.mapper.RecordMapper;
import com.hospital.service.RecordService;
import com.hospital.vo.MedicalRecordVO;
import com.hospital.vo.QuestionnaireVO;

@Service
public class RecordServiceImpl implements RecordService {

    @Autowired
    private RecordMapper recordMapper;

    @Override
    public void saveMedicalRecord(MedicalRecordVO vo) {
       recordMapper.insertMedicalRecord(vo);
    }

    @Override
    public MedicalRecordVO getRecordByReservationId(int reservationId) {
        List<MedicalRecordVO> list = recordMapper.selectRecordsByReservationId(reservationId);  // ✅ List로 받기
        return list.isEmpty() ? null : list.get(0);  // ✅ 첫 번째 진단서만 반환
    }
    
    @Override
    public List<MedicalRecordVO> getRecordsByDoctorId(String doctorId) {
        return recordMapper.getRecordsByDoctorId(doctorId);
    }
    
    @Override
    public QuestionnaireVO getQuestionnaireByReservationId(int reservationId) {
        return recordMapper.getQuestionnaireByReservationId(reservationId);
    }
}
