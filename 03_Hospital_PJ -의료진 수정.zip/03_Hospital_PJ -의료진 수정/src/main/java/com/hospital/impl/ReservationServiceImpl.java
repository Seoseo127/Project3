package com.hospital.impl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.ReservationDAO;
import com.hospital.mapper.ReservationMapper;
import com.hospital.service.ReservationService;
import com.hospital.vo.ReservationVO;

@Service
public class ReservationServiceImpl implements ReservationService {

    @Autowired
    private ReservationDAO reservationDAO;

    @Autowired
    private ReservationMapper reservationMapper;

    public void saveReservation(ReservationVO vo) {
        reservationDAO.insertReservation(vo);
    }

    public void saveReservationWithQuestionnaire(ReservationVO vo, String questionnaireContent) {
        // 예약 먼저 저장
        reservationDAO.insertReservation(vo);

        // 예약 ID 가져오기 (insertReservation에서 selectKey로 세팅되었다고 가정)
        int reservationId = vo.getReservationId();

        // 문진표 저장
        Map map = new HashMap();
        map.put("reservationId", Integer.valueOf(reservationId));
        map.put("content", questionnaireContent);

        reservationDAO.insertQuestionnaire(map);
    }

    public List<Integer> getReservedScheduleIds() {
        return reservationDAO.getReservedScheduleIds();
    }

    @Override
    public int findExistingPatient(String name, String ssn) {
        return reservationDAO.findExistingPatient(name, ssn); // ✅ 일치
    }

    
    @Override
    public int isExistingSSNOnly(String ssn) {
        return reservationDAO.isExistingSSNOnly(ssn);
    }

    public int registerNonMember(String name, String ssn, String phone) {
        Map param = new HashMap();
        param.put("name", name);
        param.put("ssn", ssn);
        param.put("phone", phone);

        reservationDAO.insertNonMember(param);
        return ((Integer) param.get("patientNo")).intValue();
    }

    @Override
    public List<ReservationVO> getTodayPatientsByDoctorId(String doctorId) {
        return reservationMapper.getTodayPatientsByDoctorId(doctorId);
    }

    @Override
    public ReservationVO getReservationById(int reservationId) {
        return reservationMapper.getReservationById(reservationId);
    }
    
 // ✅ 회원 여부 확인 메서드 구현
    @Override
    public int isExistingMember(String ssn) {
        return reservationDAO.isExistingMember(ssn);
    }
    @Override
    public String getDoctorIdByNameAndDepartment(String name, String department) {
        return reservationDAO.getDoctorIdByNameAndDepartment(name, department);
    }
    
    

    // 회원 예약 목록 조회
    @Override
    public List<ReservationVO> getReservationsByPatientNo(int patientNo) {
        List<ReservationVO> all = reservationDAO.getReservationsByPatientNo(patientNo);
        return filterFutureReservations(all);
    }

    // 비회원 예약 목록 조회
    @Override
    public List<ReservationVO> getReservationsForNonMember(String name, int patientNo) {
        Map<String, Object> param = new HashMap<>();
        param.put("name", name);
        param.put("patientNo", patientNo);
        List<ReservationVO> all = reservationDAO.getReservationsForNonMember(param);
        return filterFutureReservations(all);
    }

    // 🔍 공통 필터링 메서드
    private List<ReservationVO> filterFutureReservations(List<ReservationVO> reservations) {
        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

        return reservations.stream()
            .filter(res -> {
                LocalDate resDate = res.getReservationDate()
                                        .toInstant()
                                        .atZone(ZoneId.systemDefault())
                                        .toLocalDate();
                LocalTime resTime = LocalTime.parse(res.getScheduleTime(), formatter);
                return resDate.isAfter(today) || (resDate.isEqual(today) && resTime.isAfter(now));
            })
            .collect(Collectors.toList());
    }
    @Override
    public int getPatientNoByUserId(String userId) {
        return reservationDAO.getPatientNoByUserId(userId);
    }
    
    @Override
    public void updateStatusToCompleted(int reservationId) {
        reservationDAO.updateStatusToCompleted(reservationId);
    }
   

    // ✅ 예약 수정
    @Override
    public void updateReservation(ReservationVO vo) {
        reservationDAO.updateReservation(vo);  // ✅ DAO 방식으로 교체
    }

    @Override
    public void deleteReservation(int reservationId) {
        reservationDAO.deleteReservation(reservationId);  // ✅ DAO 방식으로 교체
    }

    
    @Override
    public void cancelReservation(int reservationId) {
        reservationDAO.cancelReservation(reservationId);
    }
    
 
}