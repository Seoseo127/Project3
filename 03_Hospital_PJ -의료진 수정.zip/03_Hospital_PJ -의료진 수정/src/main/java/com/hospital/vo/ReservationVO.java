package com.hospital.vo;

import java.util.Date;

public class ReservationVO {
   private int reservationId;
    private int patientNo;
    private String department;
    private String doctorId;
    private Date reservationDate;
    private String status;
    private Date createdAt;
    private String patientName; // 사용자 이름
    private boolean hasRecord; // 작성여부
    private int scheduleId;
    private String scheduleTime;

    
    private String doctorName;      // 의사 이름
    private String departmentName;  // 진료과 이름
    // === Getter & Setter ===
    
    
    
    
    
    public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public int getScheduleId() {
        return scheduleId;
    }
    public void setScheduleId(int scheduleId) {
        this.scheduleId = scheduleId;
    }

    public String getScheduleTime() {
        return scheduleTime;
    }
    public void setScheduleTime(String scheduleTime) {
        this.scheduleTime = scheduleTime;
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getPatientNo() {
        return patientNo;
    }

    public void setPatientNo(int patientNo) {
        this.patientNo = patientNo;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    // === toString ===

    @Override
    public String toString() {
        return "ReservationVO{" +
                "reservationId=" + reservationId +
                ", patientNo=" + patientNo +
                ", department='" + department + '\'' +
                ", doctorId='" + doctorId + '\'' +
                ", reservationDate=" + reservationDate +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public boolean isHasRecord() {
		return hasRecord;
	}
	public void setHasRecord(boolean hasRecord) {
		this.hasRecord = hasRecord;
	}
}
