package com.hospital.vo;

import java.util.Date;

public class DoctorScheduleVO {
	private int scheduleId;	
	private String doctorId;	
	private Date scheduleDate	;
	private String timeSlot;	
	private String scheduleTime;
	private String note;	
	private Date created_at;
	
	
	
	
	public int getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public Date getScheduleDate() {
		return scheduleDate;
	}
	public void setScheduleDate(Date scheduleDate) {
		this.scheduleDate = scheduleDate;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String time_slot) {
		this.timeSlot = time_slot;
	}
	public String getScheduleTime() {
		return scheduleTime;
	}
	public void setScheduleTime(String scheduleTime) {
		this.scheduleTime = scheduleTime;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public Date getCreated_at() {
		return created_at;
	}
	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}
	@Override
	public String toString() {
		return "DoctorScheduleVO [scheduleId=" + scheduleId + ", doctorId=" + doctorId + ", scheduleDate="
				+ scheduleDate + ", time_slot=" + timeSlot + ", scheduleTime=" + scheduleTime + ", note=" + note
				+ ", created_at=" + created_at + "]";
	}
	
	
	
}
