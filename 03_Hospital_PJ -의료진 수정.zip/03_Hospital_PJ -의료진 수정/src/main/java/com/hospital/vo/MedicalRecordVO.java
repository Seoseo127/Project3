    package com.hospital.vo;

    import java.util.Date;
import java.util.List;

    public class MedicalRecordVO {
        private int recordId;
        private int reservationId;
        private String doctorId;
        private String diagnosis;
        private String treatment;
        private String prescription;
        private Date recordDate;
        private String content;
        private String medication;

        // ★★★ 이 부분이 있는지 다시 한번 확인하세요! ★★★
        private String patientName;

        private String doctorName;
        
        private boolean requested; // 협진 신청 여부

        public boolean isRequested() {
            return requested;
        }

        public void setRequested(boolean requested) {
            this.requested = requested;
        }

        // --- Getter와 Setter ---
        public int getRecordId() { return recordId; }
        public void setRecordId(int recordId) { this.recordId = recordId; }
        public int getReservationId() { return reservationId; }
        public void setReservationId(int reservationId) { this.reservationId = reservationId; }
        public String getDoctorId() { return doctorId; }
        public void setDoctorId(String doctorId) { this.doctorId = doctorId; }
        public String getDiagnosis() { return diagnosis; }
        public void setDiagnosis(String diagnosis) { this.diagnosis = diagnosis; }
        public String getTreatment() { return treatment; }
        public void setTreatment(String treatment) { this.treatment = treatment; }
        public String getPrescription() { return prescription; }
        public void setPrescription(String prescription) { this.prescription = prescription; }
        public Date getRecordDate() { return recordDate; }
        public void setRecordDate(Date recordDate) { this.recordDate = recordDate; }
        public String getContent() { return content; }
        public void setContent(String content) { this.content = content; }
        public String getMedication() { return medication; }
        public void setMedication(String medication) { this.medication = medication; }
        public String getDoctorName() { return doctorName; }
        public void setDoctorName(String doctorName) { this.doctorName = doctorName; }

        // ★★★ 이 부분이 있는지 다시 한번 확인하세요! ★★★
        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }

        @Override
        public String toString() {
            return "MedicalRecordVO{" +
                    "recordId=" + recordId +
                    ", reservationId=" + reservationId +
                    ", doctorId='" + doctorId + '\'' +
                    ", diagnosis='" + diagnosis + '\'' +
                    ", treatment='" + treatment + '\'' +
                    ", prescription='" + prescription + '\'' +
                    ", recordDate=" + recordDate +
                    ", content='" + content + '\'' +
                    ", medication='" + medication + '\'' +
                    ", patientName='" + patientName + '\'' +
                    ", doctorName='" + doctorName + '\'' +
                    '}';
        }
		public List<MedicalRecordVO> getMedicalRecordsByPatientNo(int patientNo) {
			// TODO Auto-generated method stub
			return null;
		}
    }
    