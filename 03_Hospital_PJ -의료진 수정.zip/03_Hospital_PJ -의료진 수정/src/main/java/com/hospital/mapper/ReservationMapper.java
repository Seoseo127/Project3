package com.hospital.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.hospital.vo.ReservationVO;

public interface ReservationMapper {

	@Select("SELECT " +
	        "r.reservation_id AS reservationId, " +
	        "r.patient_no AS patientNo, " +
	        "r.department, " +
	        "r.doctor_id AS doctorId, " +
	        "r.reservation_date AS reservationDate, " +
	        "r.status, " +
	        "r.created_at AS createdAt, " +
	        "r.schedule_id AS scheduleId, " +
	        "r.schedule_time AS scheduleTime, " +
	        "p.patient_name AS patientName " +
	        "FROM reservations r " +
	        "JOIN patients p ON r.patient_no = p.patient_no " +
	        "WHERE r.doctor_id = #{doctorId} " +
	        "AND TRUNC(r.reservation_date) = TRUNC(SYSDATE) " +
			"AND r.status IN ('확정', '완료')")
	List<ReservationVO> getTodayPatientsByDoctorId(String doctorId);


	@Select("SELECT r.*, p.patient_name AS patientName " +
	        "FROM reservations r " +
	        "JOIN patients p ON r.patient_no = p.patient_no " +
	        "WHERE r.reservation_id = #{reservationId}")
	ReservationVO getReservationById(@Param("reservationId") int reservationId);
	
	
	
}
