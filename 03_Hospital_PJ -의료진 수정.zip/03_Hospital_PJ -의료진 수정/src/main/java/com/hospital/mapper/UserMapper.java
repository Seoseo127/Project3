package com.hospital.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Param;
import com.hospital.vo.UserVO;

@Mapper
public interface UserMapper {

    @Select("SELECT " +
            "U.USER_ID, U.NAME, U.PHONE, U.EMAIL, U.ROLE, D.BIO " +
            "FROM USERS U " +
            "LEFT JOIN DOCTOR_INFO D ON U.USER_ID = D.DOCTOR_ID " +
            "WHERE U.USER_ID = #{userId}")
    UserVO selectDoctorProfile(@Param("userId") String userId);

    @Select("SELECT * FROM USERS WHERE USER_ID = #{userId}")
    UserVO getUserById(@Param("userId") String userId);
    
    @Update("UPDATE USERS SET PASSWORD = #{password}, PHONE = #{phone}, EMAIL = #{email} WHERE USER_ID = #{userId}")
    int updateUser(UserVO user);
    
    
}
