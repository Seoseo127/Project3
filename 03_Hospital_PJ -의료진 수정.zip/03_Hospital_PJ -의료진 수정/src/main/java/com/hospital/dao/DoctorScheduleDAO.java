package com.hospital.dao;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hospital.mapper.DoctorScheduleMapper;
import com.hospital.vo.DoctorScheduleVO;

@Repository
public class DoctorScheduleDAO {

    @Autowired
    private DoctorScheduleMapper doctorScheduleMapper;

    public int insertSchedule(String doctorId, Date scheduleDate, String timeSlot, String scheduleTime, String note) {
        return doctorScheduleMapper.insertSchedule(doctorId, scheduleDate, timeSlot, scheduleTime, note);
    }

    public int deleteScheduleByDateTime(String date, String scheduleTime, String doctorId) {
        return doctorScheduleMapper.deleteScheduleByDateTime(date, scheduleTime, doctorId);
    }

    public List<DoctorScheduleVO> selectSchedulesByDate(String date) {
        return doctorScheduleMapper.selectSchedulesByDate(date);
    }

    public boolean existsSchedule(String doctorId, String date, String scheduleTime) {
        int count = doctorScheduleMapper.countScheduleByDateTime(doctorId, date, scheduleTime);
        return count > 0;
    }

    public List<DoctorScheduleVO> getSchedulesByDateAndDoctor(String date, String doctorId) {
        return doctorScheduleMapper.selectSchedulesByDateAndDoctor(date, doctorId);
    }
}
