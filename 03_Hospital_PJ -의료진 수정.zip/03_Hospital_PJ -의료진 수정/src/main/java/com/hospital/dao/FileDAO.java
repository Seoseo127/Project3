package com.hospital.dao;

public class FileDAO {

}
