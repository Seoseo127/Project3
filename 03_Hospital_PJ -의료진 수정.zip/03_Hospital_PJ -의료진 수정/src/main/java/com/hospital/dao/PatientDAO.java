package com.hospital.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.hospital.vo.PatientVO;

@Mapper
public interface PatientDAO {
	int insertPatient(PatientVO vo); // 회원가입

	PatientVO login(PatientVO vo); // 로그인

	int existsByUserId(String userId); // id 전역검사

	int existsByRrn(String rrn); // 주민번호 전역검사

	int existsByEmail(String email); // email 전역검사

	// ✅ 관리자 기능 추가
	List<PatientVO> getAllPatients();

	List<PatientVO> searchPatients(String keyword);

	void deletePatientByNo(int patientNo);              // 환자번호 기준 삭제
	void deletePatientByUserId(String patientUserId);   // 소셜 로그인 ID 기준 삭제

	
	PatientVO getPatientByNo(int patientNo);

	
	void deletePatient(String patientUserId);
	
	// 반드시 있어야 함
	void insertSocialPatient(PatientVO vo);
	PatientVO findPatientByEmail(@Param("email") String email);

	
	// ★ 이 메서드가 PatientDAO에 선언되어 있어야 합니다. ★
    PatientVO selectPatientByUserId(@Param("patientUserId") String patientUserId);


}
