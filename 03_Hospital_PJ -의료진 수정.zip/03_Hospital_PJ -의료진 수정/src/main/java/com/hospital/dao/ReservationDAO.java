package com.hospital.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.hospital.vo.ReservationVO;

public interface ReservationDAO {
    void insertReservation(ReservationVO vo);
    
    List<Integer> getReservedScheduleIds();
    
    int findExistingPatient(@Param("name") String name, @Param("ssn") String ssn);

    int isExistingMember(@Param("ssn") String ssn);
    
    int isExistingSSNOnly(String ssn);
    
    int insertNonMember(Map<String, Object> param);
    
    void insertQuestionnaire(Map param);
    
    ReservationVO getReservationById(int reservationId);
    
    void updateStatusToCompleted(int reservationId);
    
    String getDoctorIdByNameAndDepartment(@Param("name") String name, @Param("department") String department);
    
    List<ReservationVO> getReservationsByPatientNo(int patientNo);

    List<ReservationVO> getReservationsForNonMember(Map<String, Object> param);

    int getPatientNoByUserId(String userId);
    
    void updateReservation(ReservationVO vo);

    void deleteReservation(int reservationId); // 기존 삭제

    // ✅ 새로 추가: 예약 상태를 '취소'로 변경
    void cancelReservation(int reservationId);
    


    
    
 
}
