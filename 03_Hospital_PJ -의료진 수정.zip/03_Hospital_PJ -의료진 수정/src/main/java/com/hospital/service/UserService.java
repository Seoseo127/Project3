package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hospital.vo.DepartmentVO;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.UserVO;

public interface UserService {
    @Autowired
    UserVO login(UserVO vo); //로그인

    boolean insertUser(UserVO vo); //회원가입

    UserVO getDoctorProfile(String userId);

    UserVO getUserById(String userId);

    List<PartnerHospitalVO> getAllHospitals();

    List<DepartmentVO> getAllDepartments();

    List<String> getDoctorNamesByDeptId(String deptId);

    String getDoctorIdByName(String name);

    void updateUser(UserVO userVO);
}
