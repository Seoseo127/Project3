package com.hospital.service;

import java.util.List;

import com.hospital.vo.MedicalRecordVO;
import com.hospital.vo.QuestionnaireVO;

public interface RecordService {
	public void saveMedicalRecord(MedicalRecordVO vo);

	MedicalRecordVO getRecordByReservationId(int reservationId);
	List<MedicalRecordVO> getRecordsByDoctorId(String doctorId);
	QuestionnaireVO getQuestionnaireByReservationId(int reservationId);
}
