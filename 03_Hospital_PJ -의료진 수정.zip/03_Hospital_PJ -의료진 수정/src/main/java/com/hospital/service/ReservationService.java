package com.hospital.service;

import java.util.List;

import com.hospital.vo.ReservationVO;

public interface ReservationService {
    void saveReservation(ReservationVO vo);
    
    List<Integer> getReservedScheduleIds();
    

    int findExistingPatient(String name, String ssn); 

    int isExistingSSNOnly(String ssn);

    
    
    int registerNonMember(String name, String ssn, String phone);
    
    void saveReservationWithQuestionnaire(ReservationVO vo, String questionnaireContent);
    
    List<ReservationVO> getTodayPatientsByDoctorId(String doctorId);
    
    ReservationVO getReservationById(int reservationId);
    
    int isExistingMember(String ssn);
    
    String getDoctorIdByNameAndDepartment(String name, String department);
    
    
    // 회원 예약 목록 조회
    List<ReservationVO> getReservationsByPatientNo(int patientNo);

    // 비회원 예약 목록 조회
    List<ReservationVO> getReservationsForNonMember(String name, int patientNo);
    
    int getPatientNoByUserId(String userId);
    
    void updateStatusToCompleted(int reservationId);

    
   
    void updateReservation(ReservationVO vo);
    void deleteReservation(int reservationId);
    
    void cancelReservation(int reservationId);

    



}