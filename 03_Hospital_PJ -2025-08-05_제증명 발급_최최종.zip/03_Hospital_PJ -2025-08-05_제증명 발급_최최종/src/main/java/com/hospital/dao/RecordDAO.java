package com.hospital.dao;

import com.hospital.vo.QuestionnaireVO;

public interface RecordDAO {
    QuestionnaireVO getQuestionnaireByReservationId(int reservationId);
}
