package com.hospital.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Param;

import com.hospital.vo.NoticeVO;

@Mapper
public interface NoticeMapper {

    @Select("SELECT NOTICE_ID, TITLE, CONTENT, CREATED_AT, CREATED_BY, TARGET_ROLE " +
            "FROM MEDICAL_NOTICES " +
            "WHERE TARGET_ROLE = 'all' OR TARGET_ROLE = #{role} " +
            "ORDER BY CREATED_AT DESC")
    List<NoticeVO> getNoticesByRole(@Param("role") String role);

    @Select("SELECT NOTICE_ID, TITLE, CONTENT, CREATED_AT, CREATED_BY, TARGET_ROLE " +
            "FROM MEDICAL_NOTICES WHERE NOTICE_ID = #{noticeId}")
    NoticeVO getNoticeById(@Param("noticeId") int noticeId);
    
    @Select({
        "<script>",
        "SELECT NOTICE_ID, TITLE, CONTENT, CREATED_AT, CREATED_BY, TARGET_ROLE",
        "FROM MEDICAL_NOTICES",
        "WHERE (TARGET_ROLE = 'all' OR TARGET_ROLE = #{role})",
        "<if test='searchType == \"title\"'>",
        "  AND LOWER(TITLE) LIKE '%' || LOWER(#{keyword}) || '%'",
        "</if>",
        "<if test='searchType == \"writer\"'>",
        "  AND LOWER(CREATED_BY) LIKE '%' || LOWER(#{keyword}) || '%'",
        "</if>",
        "<if test='searchType == \"content\"'>",
        "  AND LOWER(CONTENT) LIKE '%' || LOWER(#{keyword}) || '%'",
        "</if>",
        "ORDER BY CREATED_AT DESC",
        "</script>"
    })
    List<NoticeVO> searchNoticesByRoleAndKeyword(@Param("role") String role,
                                                 @Param("searchType") String searchType,
                                                 @Param("keyword") String keyword);


}