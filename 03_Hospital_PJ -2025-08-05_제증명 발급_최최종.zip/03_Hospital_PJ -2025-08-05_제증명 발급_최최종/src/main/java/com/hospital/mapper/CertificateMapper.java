package com.hospital.mapper;

import com.hospital.vo.CertificateVO;
import org.apache.ibatis.annotations.Mapper; // Spring Boot가 아닌 XML 설정 기반에서는 @Mapper가 필수는 아님
import org.apache.ibatis.annotations.Param;
import java.util.List;

// XML 설정 파일에서 <mybatis-spring:scan>을 사용하면 @Mapper 어노테이션은 필수가 아닐 수 있습니다.
// 하지만 명시적으로 붙여두는 것은 좋습니다.
@Mapper
public interface CertificateMapper {

    // RQ-603: 증명서 발급 신청 - CertificateVO 객체를 받아 DB에 삽입.
    // useGeneratedKeys와 keyProperty를 사용하여 DB에서 자동 생성된 certificateId를 VO에 주입.
    // Oracle의 경우 selectKey 또는 sequence 호출 방식 사용 (XML에서)
    int insertCertificate(CertificateVO certificateVO);

    // RQ-605: 서류 발급 이력 조회 - patientNo를 기준으로 CertificateVO 리스트를 조회.
    // 환자 정보까지 함께 가져오려면 JOIN 쿼리 필요 (XML에서 resultType 대신 resultMap 사용)
    List<CertificateVO> selectCertificatesByPatientNo(@Param("patientNo") int patientNo);

    // 증명서 ID로 단일 증명서 조회 (상태 업데이트 전 정보 로드용)
    CertificateVO selectCertificateById(@Param("certificateId") int certificateId);

    // 증명서 상태 업데이트 - CertificateVO 객체를 받아 DB의 상태를 업데이트.
    int updateCertificateStatus(CertificateVO certificateVO);
    
    // 전체 증명서 개수를 세는 메서드
    int getCertificateHistoryCount(@Param("patientNo") int patientNo);

    // 페이지에 맞는 증명서 목록을 가져오는 메서드
    List<CertificateVO> getCertificateHistoryByPage(@Param("patientNo") int patientNo, @Param("startIndex") int startIndex, @Param("pageSize") int pageSize);

}