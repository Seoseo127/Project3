package com.hospital.mapper;

public interface FileMapper {

}
