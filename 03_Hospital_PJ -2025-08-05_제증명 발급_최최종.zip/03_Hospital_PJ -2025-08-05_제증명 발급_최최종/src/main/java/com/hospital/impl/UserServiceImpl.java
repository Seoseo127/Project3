package com.hospital.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.hospital.dao.UserDAO;
import com.hospital.mapper.UserMapper;
import com.hospital.service.UserService;
import com.hospital.vo.DepartmentVO;
import com.hospital.vo.DoctorVO;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.UserVO;

@Service
@Repository
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;

	@Autowired
	private SqlSessionTemplate sqlSession;

	public List<String> getDoctorNamesByDeptId(String deptId) {
		return sqlSession.selectList("com.hospital.dao.UserDAO.getDoctorNamesByDeptId", deptId);
	}

	@Override
	public UserVO login(UserVO vo) {
		return userDAO.login(vo);
	}

	@Override
	public boolean insertUser(UserVO vo) throws DuplicateKeyException {
		try {
			int result = userDAO.insertUser(vo);

			// doctor일 경우 doctor_info 자동 생성
			if (result > 0 && "doctor".equals(vo.getRole())) {
				DoctorVO doctor = new DoctorVO();
				doctor.setDoctorId(vo.getUserId());
				doctor.setDeptId(vo.getDeptId());
				doctor.setSpecialty(""); // 초기값 공백
				doctor.setBio(""); // 초기값 공백
				doctor.setProfileImagePath(""); // 초기값 공백

				userDAO.insertDoctorInfo(doctor);
			}

			return result > 0;

		} catch (DataIntegrityViolationException e) {
			Throwable cause = e.getCause();
			if (cause != null && cause.getMessage() != null) {
				String msg = cause.getMessage();
				if (msg.contains("SYS_C007381")) { // USER_ID 중복
					throw new DuplicateKeyException("이미 사용 중인 아이디입니다.");
				} else if (msg.contains("SYS_C007382")) { // RRN 중복
					throw new DuplicateKeyException("이미 등록된 주민등록번호입니다.");
				} else if (msg.contains("SYS_C007383")) { // EMAIL 중복
					throw new DuplicateKeyException("이미 등록된 이메일입니다.");
				}
			}
			throw new DuplicateKeyException("회원가입 중 알 수 없는 오류가 발생했습니다.");
		}
	}

	@Override
	public List<PartnerHospitalVO> getAllHospitals() {
		return userDAO.selectHospitals();
	}

	@Override
	public List<DepartmentVO> getAllDepartments() {
		return userDAO.selectDepartments();
	}

	@Override
	public String getDoctorIdByName(String name) {
		return userDAO.getDoctorIdByName(name);
	}

	public interface UserService {
		UserVO getDoctorProfile(String userId);
	}

	@Autowired
	private UserMapper userMapper;

	@Override
	public UserVO getDoctorProfile(String userId) {
		return userMapper.selectDoctorProfile(userId);
	}

	@Override
	public UserVO getUserById(String userId) {
		return userMapper.getUserById(userId);
	}

	@Override
	public void updateUser(UserVO userVO) {
		userMapper.updateUser(userVO);
	}
}
