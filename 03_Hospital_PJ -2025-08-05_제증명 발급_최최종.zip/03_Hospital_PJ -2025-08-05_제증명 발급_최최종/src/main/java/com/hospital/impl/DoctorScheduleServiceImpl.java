package com.hospital.impl;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DoctorScheduleDAO;
import com.hospital.mapper.DoctorScheduleMapper;
import com.hospital.service.DoctorScheduleService;
import com.hospital.vo.DoctorScheduleVO;

@Service
public class DoctorScheduleServiceImpl implements DoctorScheduleService {

    @Autowired
    private SqlSessionTemplate sqlSession;

    @Autowired
    private DoctorScheduleDAO doctorScheduleDAO;

    @Autowired
    private DoctorScheduleMapper doctorScheduleMapper;

    @Override
    public List<DoctorScheduleVO> getScheduleByDoctorName(String doctorName) {
        return sqlSession.selectList("com.hospital.mapper.DoctorScheduleMapper.getScheduleByDoctorName", doctorName);
    }

    @Override
    public int deleteScheduleByDateTime(String date, String scheduleType, String doctorId) {
        return doctorScheduleDAO.deleteScheduleByDateTime(date, scheduleType, doctorId);
    }

    @Override
    public List<DoctorScheduleVO> getSchedulesByDate(String date) {
        return doctorScheduleDAO.selectSchedulesByDate(date);
    }

    @Override
    public int registerSchedule(String doctorId, Date scheduleDate, String timeSlot, String scheduleTime, String note) {
        String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(scheduleDate);
        if (doctorScheduleDAO.existsSchedule(doctorId, dateStr, scheduleTime)) {
            return 0;
        }
        return doctorScheduleDAO.insertSchedule(doctorId, scheduleDate, timeSlot, scheduleTime, note);
    }

    @Override
    public int saveSchedule(DoctorScheduleVO vo) {
        return doctorScheduleMapper.insertSchedule(
            vo.getDoctorId(),
            new java.sql.Date(vo.getScheduleDate().getTime()),
            vo.getTimeSlot(),
            vo.getScheduleTime(),
            vo.getNote()
        );
    }

    @Override
    public List<DoctorScheduleVO> getSchedulesByDateAndDoctor(String date, String doctorId) {
        return doctorScheduleDAO.getSchedulesByDateAndDoctor(date, doctorId);
    }
}
