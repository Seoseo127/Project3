package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DoctorDAO;
import com.hospital.mapper.DoctorMapper;
import com.hospital.service.DoctorService;
import com.hospital.vo.DepartmentVO;
import com.hospital.vo.DoctorScheduleVO;
import com.hospital.vo.DoctorVO;

@Service
public class DoctorServiceImpl implements DoctorService {

    @Autowired
    private DoctorDAO doctorDAO;

    @Autowired
    private DoctorMapper doctorMapper;

    @Override
    public List<DepartmentVO> getAllDepartments() {
        return doctorDAO.getAllDepartments();
    }

    @Override
    public List<DoctorVO> getDoctorsByDeptId(String deptId) {
        return doctorDAO.getDoctorsByDeptId(deptId);
    }

    @Override
    public List<DoctorScheduleVO> getSchedulesByDoctorAndDate(String doctorId, String date) {
        return doctorDAO.getSchedulesByDoctorAndDate(doctorId, date);
    }

    @Override
    public DoctorVO getDoctorById(String doctorId) {
        return doctorMapper.getDoctorById(doctorId); 
    }

    @Override
    public void updateDoctorProfile(String doctorId, String bio) {
        doctorMapper.updateDoctorProfile(doctorId, bio);
    }
}
