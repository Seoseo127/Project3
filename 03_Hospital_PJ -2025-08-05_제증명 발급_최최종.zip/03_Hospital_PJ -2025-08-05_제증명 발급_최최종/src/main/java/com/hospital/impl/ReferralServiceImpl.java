package com.hospital.impl;

import com.hospital.dao.ReferralDAO;
import com.hospital.service.ReferralService;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReferralServiceImpl implements ReferralService {

    @Autowired
    private ReferralDAO referralDAO;

    @Override
    public ReferralRequestVO convertToReferralRequest(int recordId) {
        return referralDAO.convertToReferralRequest(recordId);
    }

    @Override
    public List<PartnerHospitalVO> getAllPartnerHospitals() {
        return referralDAO.getAllPartnerHospitals();
    }

    @Override
    public void insertReferralRequest(ReferralRequestVO requestVO) {
        referralDAO.insertReferralRequest(requestVO);
    }
    
    @Override
    public List<UserVO> getDoctorsByHospital(int hospitalId) {
        return referralDAO.getDoctorsByHospital(hospitalId);
    }
    
  
    }
