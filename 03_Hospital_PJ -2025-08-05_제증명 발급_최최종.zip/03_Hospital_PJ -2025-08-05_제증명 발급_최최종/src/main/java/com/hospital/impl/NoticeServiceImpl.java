package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.mapper.NoticeMapper;
import com.hospital.service.NoticeService;
import com.hospital.vo.NoticeVO;

@Service
public class NoticeServiceImpl implements NoticeService {

    @Autowired
    private NoticeMapper noticeMapper;

    @Override
    public List<NoticeVO> getNoticesByRole(String role) {
        return noticeMapper.getNoticesByRole(role);
    }

    @Override
    public NoticeVO getNoticeById(int noticeId) {
        return noticeMapper.getNoticeById(noticeId);
    }
    
    @Override
    public List<NoticeVO> searchNoticesByRoleAndKeyword(String role, String searchType, String keyword) {
        return noticeMapper.searchNoticesByRoleAndKeyword(role, searchType, keyword);
    }

}
