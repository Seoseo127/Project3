package com.hospital.impl;

public class FileServiceImpl {

}
