package com.hospital.service;

public class NotificationService {

}
