package com.hospital.service;

public class EventService {

}
