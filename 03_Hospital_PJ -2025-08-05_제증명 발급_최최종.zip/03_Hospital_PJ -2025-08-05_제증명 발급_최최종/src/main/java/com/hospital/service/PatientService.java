package com.hospital.service;

import java.util.List;

import com.hospital.vo.PatientVO;

public interface PatientService {
	boolean registerPatient(PatientVO vo); // 회원가입

	PatientVO login(PatientVO vo); // 로그인

	// 3. 전체 환자 목록 조회 (관리자)
	List<PatientVO> getAllPatients();

	// 4. 환자 검색 (관리자)
	List<PatientVO> searchPatients(String keyword);

	// 5. 환자 삭제 (관리자)
	void deletePatient(int patientNo);
	
	// 6. 환자 상세보기
	PatientVO getPatientByNo(int patientNo);
	
	void logdeletePatient(String patientUserId);
	
	void insertSocialPatient(PatientVO vo);
	PatientVO findPatientByEmail(String email);
	
	 // ★ 이 메서드가 반드시 선언되어 있어야 합니다. ★
    PatientVO getPatientByUserId(String patientUserId);

	
}