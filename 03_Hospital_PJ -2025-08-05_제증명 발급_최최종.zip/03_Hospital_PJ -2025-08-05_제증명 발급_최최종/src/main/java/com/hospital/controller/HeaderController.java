package com.hospital.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HeaderController {
	@RequestMapping("/header.do")
	 public String showHeader() {
	        return "header";  
	    }
	
	// 공통
	@RequestMapping("/login.do")
    public String showLoginPage() {
        return "login"; 
    }
	@RequestMapping("/mypage.do")
	public String mypage() {
		return "user/mypage";
	}

	
	@RequestMapping("/01_main_info.do")
	public String mainInfo1() {
	    return "hospital_info/01_main_info"; // 파일명에 맞게
	}
	
	@RequestMapping("/02_main_info.do")
	public String mainInfo2() {
	    return "hospital_info/02_main_info"; // 파일명에 맞게
	}
	
	@RequestMapping("/03_main_info.do")
	public String mainInfo3() {
	    return "hospital_info/03_main_info"; // 파일명에 맞게
	}

	@RequestMapping("/04_main_info.do")
	public String mainInfo4() {
	    return "hospital_info/04_main_info"; // 파일명에 맞게
	}

	// 병원 소개 (01_)
    @RequestMapping("/01_overview.do")
    public String overview() {
        return "hospital_info/01_overview";
    }

    @RequestMapping("/01_mission.do")
    public String mission() {
        return "hospital_info/01_mission";
    }

    @RequestMapping("/01_greeting.do")
    public String greeting() {
        return "hospital_info/01_greeting";
    }

    @RequestMapping("/01_history.do")
    public String history() {
        return "hospital_info/01_history";
    }

    @RequestMapping("/01_partners.do")
    public String partners() {
        return "hospital_info/01_partners";
    }

    @RequestMapping("/01_orgchart.do")
    public String orgchart() {
        return "hospital_info/01_orgchart";
    }

    @RequestMapping("/01_philosophy.do")
    public String philosophy() {
        return "hospital_info/01_philosophy";
    }

    @RequestMapping("/01_tour.do")
    public String tour() {
        return "hospital_info/01_tour";
    }

    @RequestMapping("/01_statistics.do")
    public String statistics() {
        return "hospital_info/01_statistics";
    }

    // 주요 시설 안내 (02_)
    @RequestMapping("/02_directions.do")
    public String directions() {
        return "hospital_info/02_directions";
    }

    @RequestMapping("/02_facilities.do")
    public String facilities() {
        return "hospital_info/02_facilities";
    }

    @RequestMapping("/02_convenience.do")
    public String convenience() {
        return "hospital_info/02_convenience";
    }

    @RequestMapping("/02_phone.do")
    public String phone() {
        return "hospital_info/02_phone";
    }
    
 // 병원 소식 - 공지사항
    @RequestMapping("/03_notice.do")
    public String notice() {
        return "hospital_info/03_notice";
    }

    // 병원 소식 - 언론보도
    @RequestMapping("/03_press.do")
    public String press() {
        return "hospital_info/03_press";
    }

    // 병원 소식 - 채용공고
    @RequestMapping("/03_recruit.do")
    public String recruit() {
        return "hospital_info/03_recruit";
    }

    // 병원 소식 - 병원소식지
    @RequestMapping("/03_newsletter.do")
    public String newsletter() {
        return "hospital_info/03_newsletter";
    }

    // 병원 소식 - 건강정보
    @RequestMapping("/03_healthinfo.do")
    public String healthinfo() {
        return "hospital_info/03_healthinfo";
    }

    // 사회공헌 - 기부소개
    @RequestMapping("/04_donation.do")
    public String donation() {
        return "hospital_info/04_donation";
    }

    // 사회공헌 - 의료봉사활동
    @RequestMapping("/04_volunteer.do")
    public String volunteer() {
        return "hospital_info/04_volunteer";
    }

    // 사회공헌 - ESG활동
    @RequestMapping("/04_esg.do")
    public String esg() {
        return "hospital_info/04_esg";
    }

    // 사회공헌 - 지역사회 협력
    @RequestMapping("/04_community.do")
    public String community() {
        return "hospital_info/04_community";
    }
    

}

	
