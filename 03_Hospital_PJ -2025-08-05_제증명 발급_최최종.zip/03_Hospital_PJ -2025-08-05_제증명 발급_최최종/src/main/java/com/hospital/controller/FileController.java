package com.hospital.controller;

public class FileController {

}
