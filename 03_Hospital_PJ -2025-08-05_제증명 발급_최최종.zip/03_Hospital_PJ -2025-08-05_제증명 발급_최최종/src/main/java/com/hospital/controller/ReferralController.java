package com.hospital.controller;

import com.hospital.service.ReferralService;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/referral")
public class ReferralController {

    @Autowired
    private ReferralService referralService;

    // ✅ 협진 신청 폼 호출
    @GetMapping("/requestForm.do")
    public String showReferralRequestForm(@RequestParam("recordId") int recordId, Model model) {
        ReferralRequestVO requestVO = referralService.convertToReferralRequest(recordId);
        model.addAttribute("requestVO", requestVO);

        List<PartnerHospitalVO> hospitals = referralService.getAllPartnerHospitals();
        model.addAttribute("hospitals", hospitals);

        return "doctor/referral_request_form";
    }

    // ✅ 협진 요청 등록 처리
    @PostMapping("/submitRequest.do")
    public String submitReferralRequest(@ModelAttribute ReferralRequestVO requestVO,
                                        HttpSession session) {
        UserVO loginUser = (UserVO) session.getAttribute("loginUser");

        if (loginUser == null) {
            return "redirect:/user/loginForm.do";
        }

        requestVO.setDoctorId(loginUser.getUserId()); // ✅ 보내는 의사
        // ✅ userId, hospitalId는 폼에서 선택된 값이 이미 들어옴 → set 안 해도 됨
        requestVO.setStatus("접수");

        referralService.insertReferralRequest(requestVO);
        return "redirect:/referral/history.do";
    }
    
    

    // ✅ 병원 ID로 해당 병원의 의사 목록 조회 (AJAX 용)
    @GetMapping("/doctors.do")
    @ResponseBody
    public List<UserVO> getDoctorsByHospital(@RequestParam("hospitalId") int hospitalId) {
        return referralService.getDoctorsByHospital(hospitalId);
    }
}
