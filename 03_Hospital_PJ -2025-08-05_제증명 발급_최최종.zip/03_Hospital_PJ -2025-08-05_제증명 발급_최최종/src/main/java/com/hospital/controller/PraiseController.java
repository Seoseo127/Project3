package com.hospital.controller;

import com.hospital.service.PraiseService;
import com.hospital.vo.PraiseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/praise")
public class PraiseController {

    @Autowired
    private PraiseService praiseService;

    // 칭찬릴레이 목록 페이지
    @GetMapping("/list.do")
    public String list(Model model) {
        List<PraiseVO> praiseList = praiseService.getPraiseList();
        model.addAttribute("praiseList", praiseList);
        return "praise/praiseList";
    }

    // 칭찬릴레이 상세 페이지
    @GetMapping("/detail.do")
    public String detail(@RequestParam("praiseId") int praiseId, Model model) {
        PraiseVO praise = praiseService.getPraiseDetail(praiseId);
        model.addAttribute("praise", praise);
        return "praise/praiseDetail";
    }

    // 칭찬릴레이 작성 폼 페이지
    @GetMapping("/writeForm.do")
    public String writeForm() {
        // 로그인 상태 체크 로직 필요
        // if (session.getAttribute("user") == null) { return "redirect:/login"; }
        return "praise/praiseWrite";
    }

    // 칭찬릴레이 작성 처리
    @PostMapping("/write.do")
    public String write(PraiseVO praise, HttpSession session) {
        // ========== 테스트용 강제 로그인 설정 (실제 운영 시에는 삭제해야 함) ==========
        String patientUserId = "test"; 
        session.setAttribute("patientUserId", patientUserId);
        // ====================================================================

        // 세션에서 patientUserId 가져오기 (이제 null이 아님)
        String userIdFromSession = (String) session.getAttribute("patientUserId");

        // 이 시점에서 userIdFromSession은 항상 "test"가 되어야 함
        System.out.println("TESTING: Praise write request by " + userIdFromSession);

        // 가져온 patientUserId를 PraiseVO 객체에 설정
        praise.setPatientUserId(userIdFromSession);

        // 서비스 호출
        praiseService.insertPraise(praise);

        return "redirect:/praise/list.do";
    }

    // 칭찬글 수정 폼을 보여주는 메서드
    @GetMapping("/editForm.do")
    public String editForm(@RequestParam("praiseId") int praiseId, Model model, HttpSession session) {
        // ========== 테스트용 강제 로그인 설정 (실제 운영 시에는 삭제해야 함) ==========
        String patientUserId = "test";
        session.setAttribute("patientUserId", patientUserId);
        System.out.println("TESTING: Session patientUserId is set to 'test' for editForm.");
        // ====================================================================

        // 해당 글의 상세 정보 가져오기
        PraiseVO praise = praiseService.getPraiseDetail(praiseId);

        // 글 작성자와 로그인한 사용자가 동일한지 확인
        if (!praise.getPatientUserId().equals(patientUserId)) {
            // 작성자가 아니면 권한 없음 페이지로 리다이렉트
            return "redirect:/praise/list.do";
        }

        model.addAttribute("praise", praise);
        return "praise/praiseEdit"; // praiseEdit.jsp로 이동
    }

    // 칭찬글 수정을 처리하는 메서드
    @PostMapping("/edit.do")
    public String edit(PraiseVO praise, HttpSession session) {
        // ========== 테스트용 강제 로그인 설정 (실제 운영 시에는 삭제해야 함) ==========
        String patientUserId = "test";
        session.setAttribute("patientUserId", patientUserId);
        System.out.println("TESTING: Session patientUserId is set to 'test' for edit.");
        // ====================================================================

        // 글 작성자와 로그인한 사용자가 동일한지 확인
        PraiseVO originalPraise = praiseService.getPraiseDetail(praise.getPraiseId());
        if (!originalPraise.getPatientUserId().equals(patientUserId)) {
            return "redirect:/praise/list.do";
        }

        praiseService.updatePraise(praise);

        // 수정 완료 후 상세 페이지로 리다이렉트
        return "redirect:/praise/detail.do?praiseId=" + praise.getPraiseId();
    }

    // 칭찬글 삭제를 처리하는 메서드
    @PostMapping("/delete.do")
    public String delete(@RequestParam("praiseId") int praiseId, HttpSession session) {
        // ========== 테스트용 강제 로그인 설정 (실제 운영 시에는 삭제해야 함) ==========
        String patientUserId = "test";
        session.setAttribute("patientUserId", patientUserId);
        System.out.println("TESTING: Session patientUserId is set to 'test' for delete.");
        // ====================================================================

        // 글 작성자와 로그인한 사용자가 동일한지 확인
        PraiseVO praise = praiseService.getPraiseDetail(praiseId);
        if (!praise.getPatientUserId().equals(patientUserId)) {
            return "redirect:/praise/list.do";
        }

        praiseService.deletePraise(praiseId);

        // 삭제 완료 후 목록 페이지로 리다이렉트
        return "redirect:/praise/list.do";
    }
}
