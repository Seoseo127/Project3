package com.hospital.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CommonController {

	@GetMapping("/loginSelector.do")
	public String loginSelector() {
		return "common/login_selector"; // /WEB-INF/jsp/common/login_selector.jsp
	}
}