package com.hospital.controller;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hospital.service.PatientService;
import com.hospital.vo.PatientVO;

@Controller
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientService patientService;

    // ✅ 회원가입
    @PostMapping("/signup.do")
    public String signup(@ModelAttribute PatientVO vo, HttpSession session) {
        try {
            boolean success = patientService.registerPatient(vo);
            if (success) {
                session.setAttribute("signupSuccess", "회원가입이 완료되었습니다.");
                return "redirect:/loginSelector.do";
            } else {
                session.setAttribute("signupError", "회원가입 실패. 다시 시도해주세요.");
                return "redirect:/patient/selectForm.do";
            }
        } catch (DuplicateKeyException e) {
            session.setAttribute("signupError", e.getMessage());
            return "redirect:/patient/selectForm.do";
        }
    }

    // ✅ 로그인 처리
    @PostMapping("/login.do")
    public String handleLogin(@ModelAttribute PatientVO vo, HttpSession session, RedirectAttributes redirectAttributes) {
        PatientVO loggedInPatient = patientService.login(vo); 

        if (loggedInPatient != null) {
            session.setAttribute("loggedInUserId", loggedInPatient.getPatientUserId()); 
            session.setAttribute("loggedInRole", "patient"); 
            session.setAttribute("loggedInPatientName", loggedInPatient.getPatientName()); 
            session.setAttribute("loggedInPatientNo", loggedInPatient.getPatientNo()); 
            session.setAttribute("loginUser", loggedInPatient);  // ✅ 추가 필요s
            
            return "redirect:/main.do"; 
        } else {
            return "redirect:/patient/selectForm.do"; 
        }
    }

    // ✅ 로그인 선택 폼
    @GetMapping("/selectForm.do")
    public String patientSelectForm() {
        return "patient/selectForm";
    }

    // ✅ 회원가입 폼
    @GetMapping("/signupForm.do")
    public String signupForm(HttpSession session, Model model) {
        Object error = session.getAttribute("signupError");
        if (error != null) {
            model.addAttribute("signupError", error);
            session.removeAttribute("signupError");
        }

        Object success = session.getAttribute("signupSuccess");
        if (success != null) {
            model.addAttribute("signupSuccess", success);
            session.removeAttribute("signupSuccess");
        }

        return "patient/patient_signup";
    }

    // ✅ 로그인 폼
    @GetMapping("/loginForm.do")
    public String patientLoginForm() {
        return "patient/patient_login";
    }

    // ✅ 로그아웃
    @GetMapping("/logout.do")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/loginSelector.do";
    }

    // ✅ 카카오 로그인
    @GetMapping("/kakaoLogin.do")
    public String kakaoLogin(@RequestParam("code") String code, HttpSession session) throws Exception {
        String accessToken = getAccessToken(code);
        Map<String, Object> userInfo = getUserInfo(accessToken);

        String email = (String) userInfo.get("email");
        String nickname = (String) userInfo.get("nickname");

        PatientVO patient = patientService.findPatientByEmail(email);
        if (patient == null) {
            patient = new PatientVO();
            patient.setPatientUserId("kakao_" + UUID.randomUUID().toString().substring(0, 8));
            patient.setPatientName(nickname);
            patient.setPatientEmail(email);
            patient.setPatientPassword("");
            patient.setPatientRrn("999999-" + (new Random().nextInt(900000) + 100000));

            patientService.insertSocialPatient(patient);
        }

        session.setAttribute("loginUser", patient);
        return "redirect:/resources/index.jsp";
    }

    // 🔐 카카오 access token 요청
    private String getAccessToken(String code) throws Exception {
        URL url = new URL("https://kauth.kakao.com/oauth/token");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);

        String data = "grant_type=authorization_code"
                + "&client_id=8439ac1e9e2f3cf860f6ab16dbcd581a"
                + "&redirect_uri=http://localhost:8080/patient/kakaoLogin.do"
                + "&code=" + code;

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
        bw.write(data);
        bw.flush();

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);

        JSONObject json = new JSONObject(sb.toString());
        return json.getString("access_token");
    }

    // 🔐 사용자 정보 요청
    private Map<String, Object> getUserInfo(String accessToken) throws Exception {
        URL url = new URL("https://kapi.kakao.com/v2/user/me");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);

        JSONObject json = new JSONObject(sb.toString());
        JSONObject kakaoAccount = json.getJSONObject("kakao_account");
        JSONObject profile = kakaoAccount.getJSONObject("profile");

        Map<String, Object> result = new HashMap<String, Object>();

        result.put("email", kakaoAccount.getString("email"));
        result.put("nickname", profile.getString("nickname"));
        return result;
    }

    // ✅ 회원 탈퇴
    @PostMapping("/delete.do")
    public String deletePatient(HttpSession session) {
        PatientVO loginUser = (PatientVO) session.getAttribute("loginUser");

        if (loginUser != null) {
            int patientNo = loginUser.getPatientNo();
            patientService.deletePatient(patientNo);
            session.invalidate();
        }

        return "redirect:/main.do?deleted=1";
    }
}
