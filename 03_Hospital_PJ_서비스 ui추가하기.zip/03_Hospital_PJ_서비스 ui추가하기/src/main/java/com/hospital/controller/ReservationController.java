package com.hospital.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.hospital.service.ReservationService;

@Controller
@RequestMapping("/admin")
public class ReservationController {

	@Autowired
	private ReservationService reservationService;

	@PostMapping("/updateStatus.do")
	public String updateStatus(@RequestParam("reservationId") int reservationId, @RequestParam("status") String status,
			@RequestParam("doctorId") String doctorId) {
		reservationService.updateReservationStatus(reservationId, status);
		return "redirect:/admin/doctorDetail.do?doctorId=" + doctorId;
	}
}
