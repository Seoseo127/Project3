package com.hospital.controller;

public class AuthController {

}	
