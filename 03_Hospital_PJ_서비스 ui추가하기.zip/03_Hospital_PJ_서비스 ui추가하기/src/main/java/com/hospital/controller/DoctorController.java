package com.hospital.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.hospital.service.DoctorScheduleService;
import com.hospital.service.DoctorService;
import com.hospital.vo.DepartmentVO;
import com.hospital.vo.DoctorScheduleVO;
import com.hospital.vo.DoctorVO;
import com.hospital.vo.MedicalRecordVO;
import com.hospital.vo.ReservationVO;
import com.hospital.vo.UserVO;

@Controller
@RequestMapping("/admin")
public class DoctorController {

	@Autowired
	private DoctorService doctorService;

	@Autowired
	private DoctorScheduleService doctorScheduleService;

	// 의사 목록
	@GetMapping("/doctorList.do")
	public String doctorList(Model model) {
		List<DoctorVO> list = doctorService.getAllDoctors();
		List<DepartmentVO> deptList = doctorService.getAllDepartments();
		model.addAttribute("doctorList", list);
		model.addAttribute("deptList", deptList);
		return "admin/admin_doctor_manage";
	}

	// 과별 의사 목록
	@ResponseBody
	@GetMapping(value = "/getDoctorsByDept.do", produces = "application/json; charset=UTF-8")
	public List<DoctorVO> getDoctorsByDept(@RequestParam("deptId") String deptId) {
		return doctorService.getDoctorsByDept(deptId);
	}

	// 검색
	@GetMapping("/doctorSearch.do")
	public String searchDoctors(@RequestParam("keyword") String keyword, Model model) {
		List<DoctorVO> list = doctorService.searchDoctors(keyword);
		List<DepartmentVO> deptList = doctorService.getAllDepartments();
		model.addAttribute("doctorList", list);
		model.addAttribute("deptList", deptList);
		return "admin/admin_doctor_manage";
	}

	// 의사 수정
	@PostMapping("/updateDoctor.do")
	public String updateDoctor(DoctorVO doctor) {
		doctorService.updateDoctor(doctor);
		return "redirect:/admin/doctorList.do";
	}

	// 의사 삭제
	@PostMapping("/deleteDoctor.do")
	public String deleteDoctor(@RequestParam("doctorId") String doctorId) {
		doctorService.deleteDoctor(doctorId);
		return "redirect:/admin/doctorList.do";
	}

	// 의사 수정 폼
	@GetMapping("/editDoctorForm.do")
	public String editDoctorForm(@RequestParam("doctorId") String doctorId, Model model) {
		DoctorVO doctor = doctorService.getDoctorById(doctorId);
		List<DepartmentVO> deptList = doctorService.getAllDepartments();
		model.addAttribute("doctor", doctor);
		model.addAttribute("deptList", deptList);
		return "admin/edit_doctor_form";
	}

	// 진료과 변경
	@PostMapping("/updateDoctorDept.do")
	public String updateDoctorDept(@ModelAttribute DoctorVO doctor) {
		doctorService.updateDoctorDept(doctor);
		return "redirect:/admin/doctorList.do";
	}

	// 의사 상세
	@GetMapping("/doctorDetail.do")
	public String viewDoctorDetail(@RequestParam("doctorId") String doctorId, Model model) {
		DoctorVO doctor = doctorService.getDoctorById(doctorId);
		List<DoctorScheduleVO> schedules = doctorScheduleService.getSchedulesByDoctorId(doctorId);
		List<MedicalRecordVO> records = doctorService.getRecordsByDoctorId(doctorId);
		List<ReservationVO> reservations = doctorService.getReservationsByDoctorId(doctorId);

		model.addAttribute("doctor", doctor);
		model.addAttribute("schedules", schedules);
		model.addAttribute("records", records);
		model.addAttribute("reservations", reservations);
		return "admin/doctor_detail";
	}

	// 스케줄 삭제
	@PostMapping("/deleteSchedule.do")
	public String deleteSchedule(@RequestParam("scheduleId") int scheduleId,
			@RequestParam("doctorId") String doctorId) {
		doctorScheduleService.deleteSchedule(scheduleId);
		return "redirect:/admin/doctorDetail.do?doctorId=" + doctorId;
	}

	// 스케줄 수정 처리
	@PostMapping("/updateSchedule.do")
	public String updateSchedule(@ModelAttribute DoctorScheduleVO schedule) {
		doctorScheduleService.updateSchedule(schedule);
		return "redirect:/admin/doctorDetail.do?doctorId=" + schedule.getDoctorId();
	}

	// 스케줄 수정 폼 이동
	@GetMapping("/updateScheduleForm.do")
	public String updateScheduleForm(@RequestParam("scheduleId") int scheduleId, Model model) {
		DoctorScheduleVO schedule = doctorScheduleService.getScheduleById(scheduleId);
		model.addAttribute("schedule", schedule);
		model.addAttribute("mode", "update");
		return "admin/schedule_form";
	}

	// 스케줄 등록 폼 이동
	@GetMapping("/insertScheduleForm.do")
	public String insertScheduleForm(@RequestParam("doctorId") String doctorId, Model model) {
		DoctorScheduleVO schedule = new DoctorScheduleVO();
		schedule.setDoctorId(doctorId);
		model.addAttribute("schedule", schedule);
		model.addAttribute("mode", "insert");
		return "admin/schedule_form";
	}

	// 스케줄 등록 처리
	@PostMapping("/insertSchedule.do")
	public String insertSchedule(@ModelAttribute DoctorScheduleVO schedule) {
		doctorScheduleService.insertSchedule(schedule);
		return "redirect:/admin/doctorDetail.do?doctorId=" + schedule.getDoctorId();
	}

	
}
