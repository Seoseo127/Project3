package com.hospital.controller;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.text.Collator;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Comparator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hospital.service.DepartmentService;
import com.hospital.service.DoctorService;
import com.hospital.vo.DepartmentVO;
import com.hospital.vo.DoctorScheduleVO;
import com.hospital.vo.DoctorVO;

@Controller
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;
	
	@Autowired
	private DoctorService doctorService;

	// 진료과 전체 목록
	@GetMapping("/departmentList.do")
	public String departmentList(Model model) {
		List<DepartmentVO> list = departmentService.getAllDepartments();
		model.addAttribute("departments", list);
		return "doctor/departmentList"; // /WEB-INF/jsp/doctor/departmentList.jsp
	}

	// 진료과 상세 조회
	@GetMapping("/departmentDetail.do")
	public String departmentDetail(@RequestParam("deptId") String deptId, 
	                               @RequestParam(value = "category", required = false) String category,
	                               Model model) {
	    DepartmentVO dept = departmentService.getDepartmentById(deptId);
	    model.addAttribute("dept", dept);

	    // category가 null이거나 빈 문자열일 경우 description을 기본값으로 사용
	    if (category == null || category.trim().isEmpty()) {
	        category = dept.getDescription();
	    }

	    model.addAttribute("category", category);
	    
	    List<DoctorVO> doctorList = doctorService.getDoctorsByDept(deptId);
	    model.addAttribute("doctorList", doctorList);

	    return "doctor/departmentDetail";
	}
	
	// 사용자용 의료진 전체 목록
	@GetMapping("/doctor/list.do")
	public String doctorList(@RequestParam(value = "keyword", required = false) String keyword, Model model) {
	    List<DoctorVO> doctorList;
	    if (keyword != null && !keyword.trim().isEmpty()) {
	        doctorList = doctorService.searchDoctors(keyword);
	    } else {
	        doctorList = doctorService.getAllDoctors();
	    }

	    // 이름 기준 가나다순 정렬
	    doctorList.sort(Comparator.comparing(DoctorVO::getName, Collator.getInstance(Locale.KOREAN)));

	    model.addAttribute("doctorList", doctorList);
	    model.addAttribute("keyword", keyword);
	    return "doctor/doctorList";
	}


	// 사용자용 의료진 상세 정보
	@GetMapping("/doctor/view.do")
	public String publicDoctorDetail(@RequestParam("doctorId") String doctorId, Model model) {
	    DoctorVO doctor = doctorService.getDoctorById(doctorId);
	    List<DoctorScheduleVO> scheduleList = doctorService.getSchedulesByDoctorId(doctorId);

	    Map<String, String> scheduleMap = new HashMap<>();
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("E", Locale.KOREAN); // 월, 화, 수...

	    for (DoctorScheduleVO s : scheduleList) {
	        LocalDate localDate = s.getScheduleDate().toInstant()
	                                .atZone(ZoneId.systemDefault())
	                                .toLocalDate();
	        String day = localDate.format(formatter); // ex: "월"
	        String key = day + "_" + s.getTimeSlot(); // ex: "월_오전"
	        scheduleMap.put(key, s.getNote()); // ✅ 실제 note 값 사용
	    }

	    model.addAttribute("doctor", doctor);
	    model.addAttribute("scheduleList", scheduleList);
	    model.addAttribute("scheduleMap", scheduleMap);
	    model.addAttribute("days", Arrays.asList("월", "화", "수", "목", "금", "토"));
	    return "doctor/doctorDetail";
	}
}  
