package com.hospital.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import com.hospital.service.DoctorService;
import com.hospital.service.ReferralService;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;

@Controller
@RequestMapping("/admin")
public class ReferralController {

	@Autowired
	private ReferralService referralService;

	@Autowired
	private DoctorService doctorService;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	// 협진 전체 조회
	@GetMapping("/coopLog.do")
	public String showAllReferrals(Model model, HttpSession session) {
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		model.addAttribute("loginUser", loginUser);
		if (loginUser == null || !"admin".equals(loginUser.getRole())) {
			return "redirect:/common/login_selector.jsp";
		}

		List<ReferralRequestVO> referrals = referralService.getAllReferrals();
		model.addAttribute("referrals", referrals);
		return "admin/referral_list";
	}

	// 상태별 필터링
	@GetMapping("/filterCoopLog.do")
	public String filterReferrals(@RequestParam("status") String status, Model model) {
		List<ReferralRequestVO> referrals = referralService.getReferralsByStatus(status);
		model.addAttribute("referrals", referrals);
		return "admin/referral_list";
	}

	// 협진 상세보기
	@GetMapping("/referralDetail.do")
	public String viewReferralDetail(@RequestParam("requestId") int requestId, Model model) {
		ReferralRequestVO referral = referralService.getReferralById(requestId);
		model.addAttribute("referral", referral);
		return "admin/referral_detail";
	}

	// 협진 상태 업데이트
	@PostMapping("/updateReferralStatus.do")
	public String updateReferralStatus(@RequestParam("requestId") int requestId,
			@RequestParam("status") String status) {
		referralService.updateReferralStatus(requestId, status);
		return "redirect:/admin/coopLog.do";
	}

	// 협진 요청 등록 폼 이동
	@GetMapping("/referralForm.do")
	public String showReferralForm(@RequestParam(value = "coopUserId", required = false) String coopUserId,
			@RequestParam(value = "coopHospitalId", required = false) Integer coopHospitalId, Model model,
			HttpSession session) {

		UserVO loginUser = (UserVO) session.getAttribute("loginUser");
		if (loginUser == null || !("admin".equals(loginUser.getRole()) || "coop".equals(loginUser.getRole()))) {
			return "redirect:/common/login_selector.jsp";
		}

		if ("admin".equals(loginUser.getRole())) {
			model.addAttribute("coopUserId", coopUserId);
			model.addAttribute("coopHospitalId", coopHospitalId);
		}

		model.addAttribute("deptList", doctorService.getAllDepartments());
		model.addAttribute("loginUser", loginUser); // 로그인 정보도 JSP에서 사용 중
		return "admin/referral_form";
	}

	// 협진 요청 등록 처리
	@PostMapping("/submit.do")
	public String submitReferral(ReferralRequestVO vo,
			@RequestParam(value = "coopUserId", required = false) String coopUserId,
			@RequestParam(value = "coopHospitalId", required = false) Integer coopHospitalId, HttpSession session,
			Model model) {
		UserVO loginUser = (UserVO) session.getAttribute("loginUser");

		if (loginUser == null || !("coop".equals(loginUser.getRole()) || "admin".equals(loginUser.getRole()))) {
			return "redirect:/common/login_selector.jsp";
		}

		if ("admin".equals(loginUser.getRole())) {
			if (coopUserId == null || coopHospitalId == null) {
				model.addAttribute("error", "협력 사용자 정보가 누락되었습니다.");
				model.addAttribute("deptList", doctorService.getAllDepartments());
				return "admin/referral_form";
			}
			vo.setUserId(coopUserId);
			vo.setHospitalId(coopHospitalId);
		} else {
			if (loginUser.getUserId() == null || loginUser.getHospitalId() == null) {
				model.addAttribute("error", "로그인 사용자 정보가 누락되었습니다.");
				return "redirect:/common/login_selector.jsp";
			}
			vo.setUserId(loginUser.getUserId());
			vo.setHospitalId(loginUser.getHospitalId());
		}

		vo.setStatus("접수");
		referralService.insertReferral(vo);
		model.addAttribute("message", "협진 요청이 성공적으로 등록되었습니다.");

		return "admin".equals(loginUser.getRole()) ? "redirect:/admin/coopLog.do" : "redirect:/coop/coop_main.jsp";
	}

	// 협력의사의 내 협진 목록
	@GetMapping("/myReferrals.do")
	public String viewReferralsByUser(@RequestParam("userId") String userId,
			@RequestParam(value = "hospitalId", required = false) Integer hospitalId, Model model) {
		List<ReferralRequestVO> referrals = referralService.getReferralsByUserId(userId);
		model.addAttribute("referrals", referrals);
		model.addAttribute("coopUserId", userId); // 🔽 등록 폼으로 넘길 ID
		model.addAttribute("coopHospitalId", hospitalId); // 🔽 등록 폼으로 넘길 병원 ID

		return "admin/referral_list";
	}

}
