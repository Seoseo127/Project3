package com.hospital.controller;

import com.hospital.service.EventService;
import com.hospital.vo.EventVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class InformationController {

    @Autowired
    private EventService eventService;

    
    // =======================[ 언론보도 ]=============================
    
    // 언론보도 - 목록
    @GetMapping("/03_press.do")
    public String pressPage(@RequestParam(value = "page", defaultValue = "1") int page,
                                 Model model) {
        int pageSize = 5;
        int offset = (page - 1) * pageSize;

        int totalCount = eventService.countEventsByCategory("언론");
        int totalPages = (int) Math.ceil((double) totalCount / pageSize);
        List<EventVO> list = eventService.getEventsByCategoryWithPaging("언론", offset, pageSize);

        model.addAttribute("events", list);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        return "hospital_info/03_press";
    }
    
    // 언론보도 - 상세페이지
    @GetMapping("/03_press_view.do")
    public String pressView(@RequestParam("eventId") int eventId, Model model) {
        EventVO event = eventService.getEventByIdInfo(eventId);
        model.addAttribute("event", event);
        model.addAttribute("title", "언론 보도");
        return "hospital_info/03_press_view";
    }
    
    
    // =======================[ 채용 공고 ]=============================
    
    // 채용공고 - 목록
    @GetMapping("/03_recruit.do")
    public String recruitPage(@RequestParam(value = "page", defaultValue = "1") int page,
                              Model model) {
        int pageSize = 5;
        int offset = (page - 1) * pageSize;

        int totalCount = eventService.countEventsByCategory("채용");
        int totalPages = (int) Math.ceil((double) totalCount / pageSize);
        List<EventVO> list = eventService.getEventsByCategoryWithPaging("채용", offset, pageSize);

        model.addAttribute("events", list);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        return "hospital_info/03_recruit";
    }
    
    // 채용공고 - 상세페이지
    @GetMapping("/03_recruit_view.do")
    public String recruitView(@RequestParam("eventId") int eventId, Model model) {
        EventVO event = eventService.getEventByIdInfo(eventId);
        model.addAttribute("event", event);
        model.addAttribute("title", "채용 공고");
        return "hospital_info/03_view";
    }
    
    // =======================[ 병원 소식 ]=============================
    
    // 병원소식 - 목록
    @GetMapping("/03_news.do")
    public String newsPage(@RequestParam(value = "page", defaultValue = "1") int page,
                            Model model) {
        int pageSize = 5;
        int offset = (page - 1) * pageSize;

        int totalCount = eventService.countEventsByCategory("소식");
        int totalPages = (int) Math.ceil((double) totalCount / pageSize);
        List<EventVO> list = eventService.getEventsByCategoryWithPaging("소식", offset, pageSize);

        model.addAttribute("events", list);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        return "hospital_info/03_news";
    }
    
    // 병원소식 - 상세페이지
    @GetMapping("/03_news_view.do")
    public String newsView(@RequestParam("eventId") int eventId, Model model) {
        EventVO event = eventService.getEventByIdInfo(eventId);
        model.addAttribute("event", event);
        model.addAttribute("title", "병원 소식");
        return "hospital_info/03_view";
    }

    
    // =======================[ 건강 정보 ]=============================
    
    
    

    
    
    
    
    
    //================================================================
    // [공통] // 채용 - 병원 소식
    

    // 작성
    @PostMapping("/info/03_write.do")
    public String writeEventInfo(@ModelAttribute EventVO eventVO) {
        eventService.insertEventInfo(eventVO);
        // 등록 후 카테고리에 맞는 목록으로 리다이렉트
        String category = eventVO.getCategory();
        switch (category) {
            case "소식":
                return "redirect:/03_news.do";
            case "채용":
                return "redirect:/03_recruit.do";
            default:
                return "redirect:/";
        }
    }
    
    // 작성 폼 이동
    @GetMapping("/info/03_write.do")
    public String showWriteFormInfo(@RequestParam("category") String category, Model model) {
        model.addAttribute("category", category);
        return "hospital_info/03_write";
    }

    
    // 수정 폼 이동
    @GetMapping("/info/03_edit.do")
    public String editFormInfo(@RequestParam("eventId") int eventId, Model model) {
        EventVO event = eventService.getEventByIdInfo(eventId);
        model.addAttribute("event", event);
        return "hospital_info/03_write"; // 기존 write.jsp 재사용
    }

    // 수정 처리
    @PostMapping("/info/03_update.do")
    public String updateEventInfo(@ModelAttribute EventVO eventVO) {
        eventService.updateEventInfo(eventVO);
        return "redirect:/03_" + getPathKey(eventVO.getCategory()) + ".do";
    }

    // 삭제 처리
    @GetMapping("/info/03_delete.do")
    public String deleteEventInfo(@RequestParam("eventId") int eventId, @RequestParam("category") String category) {
        eventService.deleteEventInfo(eventId);
        return "redirect:/03_" + getPathKey(category) + ".do";
    }
    
    
    // category → pathKey 매핑
    private String getPathKey(String category) {
        switch (category) {
            case "소식": return "news";
            case "채용": return "recruit";
            default: return "news";
        }
    }
    
    //페이징
    @GetMapping("/info/03_list.do")
    public String eventList(@RequestParam("category") String category,
                            @RequestParam(value = "page", defaultValue = "1") int page,
                            Model model) {
        int pageSize = 5;
        int offset = (page - 1) * pageSize;

        int totalCount = eventService.countEventsByCategory(category);
        int totalPages = (int) Math.ceil((double) totalCount / pageSize);
        List<EventVO> list = eventService.getEventsByCategoryWithPaging(category, offset, pageSize);

        model.addAttribute("events", list);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("category", category);

        // 카테고리별 뷰 분기
        switch (category) {
            case "소식": return "hospital_info/03_news";
            case "채용": return "hospital_info/03_recruit";
            default: return "redirect:/";
        }
    }

    



}
