package com.hospital.impl;

public class QnaServiceImpl {

}
