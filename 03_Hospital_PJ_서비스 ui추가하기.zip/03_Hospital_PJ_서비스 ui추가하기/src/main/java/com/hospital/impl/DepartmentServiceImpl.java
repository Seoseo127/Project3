package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DepartmentDAO;
import com.hospital.service.DepartmentService;
import com.hospital.vo.DepartmentVO;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentDAO departmentDAO;

	@Override
	public List<DepartmentVO> getAllDepartments() {
		return departmentDAO.getAllDepartments();
	}

	@Override
	public DepartmentVO getDepartmentById(String deptId) {
		return departmentDAO.getDepartmentById(deptId);
	}
}
