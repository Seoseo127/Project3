package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.ReservationDAO;
import com.hospital.service.ReservationService;
import com.hospital.vo.ReservationVO;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	private ReservationDAO reservationDAO;

	@Override
	public List<ReservationVO> getReservationsByPatientNo(int patientNo) {
		return reservationDAO.getReservationsByPatientNo(patientNo);
	}

	@Override
	public boolean insertReservation(ReservationVO vo) {
		return reservationDAO.insertReservation(vo) > 0;
	}

	@Override
	public void updateReservationStatus(int reservationId, String status) {
		reservationDAO.updateReservationStatus(reservationId, status);
	}

	@Override
	public int countTodayReservations() {
		return reservationDAO.countTodayReservations();
	}
}