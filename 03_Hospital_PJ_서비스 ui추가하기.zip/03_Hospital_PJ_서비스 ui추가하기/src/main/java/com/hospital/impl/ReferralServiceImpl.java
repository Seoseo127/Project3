package com.hospital.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hospital.dao.ReferralDAO;
import com.hospital.service.ReferralService;
import com.hospital.vo.ReferralRequestVO;

@Service
public class ReferralServiceImpl implements ReferralService {

	@Autowired
	private ReferralDAO referralDAO;

	@Override
	public List<ReferralRequestVO> getAllReferrals() {
		return referralDAO.getAllReferrals();
	}

	@Override
	public List<ReferralRequestVO> getReferralsByStatus(String status) {
		return referralDAO.getReferralsByStatus(status);
	}

	@Override
	public ReferralRequestVO getReferralById(int requestId) {
		return referralDAO.getReferralById(requestId);
	}

	@Override
	public boolean updateReferralStatus(int requestId, String status) {
		return referralDAO.updateReferralStatus(requestId, status) > 0;
	}

	@Override
	public void insertReferral(ReferralRequestVO vo) {
		referralDAO.insertReferral(vo);
	}

	@Override
	public List<ReferralRequestVO> getReferralsByUserId(String userId) {
		return referralDAO.getReferralsByUserId(userId);
	}

	@Override
	public List<ReferralRequestVO> getReferralsSorted(String status, String sort, String order) {
		return referralDAO.getReferralsSorted(status, sort, order);
	}

	@Override
	public List<ReferralRequestVO> getReferralsByKeyword(String keyword) {
		return referralDAO.getReferralsByKeyword(keyword);
	}

}
