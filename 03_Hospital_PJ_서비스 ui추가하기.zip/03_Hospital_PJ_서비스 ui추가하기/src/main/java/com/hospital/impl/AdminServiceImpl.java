package com.hospital.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.AdminDAO;
import com.hospital.service.AdminService;
import com.hospital.vo.AdminVO;
import com.hospital.vo.FeedbackVO;
import com.hospital.vo.ReservationVO;
import com.hospital.vo.UserVO;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDAO adminDAO;

	@Override
	public AdminVO login(String adminId, String password) {
		return adminDAO.login(adminId, password);
	}

	@Override
	public void insertAdmin(AdminVO vo) {
		adminDAO.insertAdmin(vo);
	}

	@Override
	public int getAdmittedPatientCount() {
		return adminDAO.countAdmittedPatients();
	}

	@Override
	public int getUnreadNoticeCount() {
		return adminDAO.countUnreadNotices();
	}

	@Override
	public int getTotalReferralCount() {
		return adminDAO.countTotalReferrals();
	}

	@Override
	public int getRepliedReferralCount() {
		return adminDAO.countRepliedReferrals();
	}

	@Override
	public int countFeedbackByStatus(String status) {
		return adminDAO.countFeedbackByStatus(status);
	}

	@Override
	public List<FeedbackVO> getRecentFeedbacksByStatus(String status) {
		return adminDAO.getRecentFeedbacksByStatus(status);
	}

	@Override
	public List<ReservationVO> getReservationStatsLast7Days() {
		return adminDAO.getReservationStatsLast7Days();
	}

	@Override
	public void updateUserRole(String userId, String role) {
		adminDAO.updateUserRole(userId, role);
	}

	@Override
	public List<UserVO> getAllUsers() {
		return adminDAO.getAllUsers();
	}

	@Override
	public List<ReservationVO> getReservationSummaryByDateRange() {
		return adminDAO.getReservationSummaryByDateRange();
	}

	@Override
	public List<ReservationVO> getReservationsByDate(String date) {
		return adminDAO.getReservationsByDate(date);
	}

}
