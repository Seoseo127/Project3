package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DoctorScheduleDAO;
import com.hospital.service.DoctorScheduleService;
import com.hospital.vo.DoctorScheduleVO;

@Service
public class DoctorScheduleServiceImpl implements DoctorScheduleService {

	@Autowired
	private DoctorScheduleDAO doctorScheduleDAO;

	@Override
	public List<DoctorScheduleVO> getSchedulesByDoctorId(String doctorId) {
		return doctorScheduleDAO.getSchedulesByDoctorId(doctorId);
	}

	@Override
	public void deleteSchedule(int scheduleId) {
		doctorScheduleDAO.deleteSchedule(scheduleId);
	}

	@Override
	public DoctorScheduleVO getScheduleById(int scheduleId) {
		return doctorScheduleDAO.getScheduleById(scheduleId);
	}

	@Override
	public void updateSchedule(DoctorScheduleVO vo) {
		doctorScheduleDAO.updateSchedule(vo);
	}

	@Override
	public void insertSchedule(DoctorScheduleVO vo) {
		doctorScheduleDAO.insertSchedule(vo);
	}
}
