package com.hospital.impl;

public class NotificationServiceImpl {

}
