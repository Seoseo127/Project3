package com.hospital.service;

import java.util.List;
import com.hospital.vo.DepartmentVO;

public interface DepartmentService {
    List<DepartmentVO> getAllDepartments();
    DepartmentVO getDepartmentById(String deptId);
    
    
}
