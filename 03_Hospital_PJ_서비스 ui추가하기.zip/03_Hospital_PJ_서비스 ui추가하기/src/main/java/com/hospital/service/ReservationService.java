package com.hospital.service;

import java.util.List;

import com.hospital.vo.ReservationVO;

public interface ReservationService {
	List<ReservationVO> getReservationsByPatientNo(int patientNo);

	boolean insertReservation(ReservationVO vo);

	void updateReservationStatus(int reservationId, String status);

	int countTodayReservations();
}
