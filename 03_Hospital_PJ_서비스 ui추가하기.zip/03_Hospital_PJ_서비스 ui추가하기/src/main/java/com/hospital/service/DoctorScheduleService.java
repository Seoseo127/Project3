package com.hospital.service;

import java.util.List;
import com.hospital.vo.DoctorScheduleVO;

public interface DoctorScheduleService {
	List<DoctorScheduleVO> getSchedulesByDoctorId(String doctorId);

	void deleteSchedule(int scheduleId);

	DoctorScheduleVO getScheduleById(int scheduleId);

	void updateSchedule(DoctorScheduleVO vo);

	void insertSchedule(DoctorScheduleVO vo);
}
