package com.hospital.service;

import java.util.List;
import com.hospital.vo.ReferralRequestVO;

public interface ReferralService {

	List<ReferralRequestVO> getAllReferrals();

	List<ReferralRequestVO> getReferralsByStatus(String status);

	ReferralRequestVO getReferralById(int requestId);

	boolean updateReferralStatus(int requestId, String status);

	void insertReferral(ReferralRequestVO vo);

	List<ReferralRequestVO> getReferralsByUserId(String userId);

	List<ReferralRequestVO> getReferralsSorted(String status, String sort, String order);

	List<ReferralRequestVO> getReferralsByKeyword(String keyword);

}
