package com.hospital.service;

import com.hospital.dao.EventDAO;
import com.hospital.vo.EventVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {

	@Autowired
	private EventDAO eventDAO;

	public List<EventVO> getEventsByCategoryInfo(String category) {
		return eventDAO.selectEventsByCategoryInfo(category);
	}

	public EventVO getEventByIdInfo(int eventId) {
		return eventDAO.selectEventByIdInfo(eventId); // ✅ 수정된 부분
	}

	public void insertEventInfo(EventVO eventVO) {
		eventDAO.insertEventInfo(eventVO);
	}

	public void updateEventInfo(EventVO eventVO) {
		eventDAO.updateEventInfo(eventVO);
	}

	public void deleteEventInfo(int eventId) {
		eventDAO.deleteEventInfo(eventId);
	}

	public List<EventVO> getGeneralInfoEventsInfo() {
		return eventDAO.selectGeneralInfoEventsInfo();
	}

	// 페이징
	public int countEventsByCategory(String category) {
		return eventDAO.countEventsByCategory(category);
	}

	public List<EventVO> getEventsByCategoryWithPaging(String category, int offset, int pageSize) {
		return eventDAO.selectEventsByCategoryWithPaging(category, offset, pageSize);
	}

	public void incrementViewCount(int eventId) {
		eventDAO.updateViewCount(eventId);
	}

	public List<EventVO> getEventsByCategory(String category) {
		return eventDAO.selectEventsByCategoryInfo(category);
	}

	// 🔽 새로 추가: 특정 카테고리들에 대해 필터링된 강좌/행사 목록 조회
	public List<EventVO> getFilteredEvents(List<String> categories, int offset, int limit) {
		return eventDAO.selectFilteredEvents(categories, offset, limit);
	}

	// Service
	public void insertLectureEvent(EventVO event) {
		eventDAO.insertLectureEvent(event);
	}

}
