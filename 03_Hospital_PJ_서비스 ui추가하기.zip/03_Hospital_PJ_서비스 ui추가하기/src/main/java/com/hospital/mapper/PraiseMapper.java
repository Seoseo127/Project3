package com.hospital.mapper;

import com.hospital.vo.PraiseVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PraiseMapper {
    List<PraiseVO> selectPraiseList();
    
    PraiseVO selectPraiseDetail(int praiseId);
    
    void updateViewCount(int praiseId);
    
    void insertPraise(PraiseVO praise);
    
    // 칭찬글 수정 메서드 추가
    void updatePraise(PraiseVO praise);

    // 칭찬글 삭제 메서드 추가
    void deletePraise(int praiseId);
}