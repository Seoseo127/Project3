package com.hospital.mapper;

public interface EventMapper {

}
