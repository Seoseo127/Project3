package com.hospital.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.hospital.vo.NoticeVO;

@Mapper
public interface NoticeMapper {
    void insertNotice(NoticeVO notice);
    List<NoticeVO> getAllNotices();
    NoticeVO getNoticeById(int id);
    void updateNotice(NoticeVO notice);
    void deleteNotice(int id);
}
