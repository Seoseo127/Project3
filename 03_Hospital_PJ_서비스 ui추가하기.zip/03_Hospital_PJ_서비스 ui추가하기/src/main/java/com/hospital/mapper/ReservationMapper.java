package com.hospital.mapper;

public interface ReservationMapper {

}
