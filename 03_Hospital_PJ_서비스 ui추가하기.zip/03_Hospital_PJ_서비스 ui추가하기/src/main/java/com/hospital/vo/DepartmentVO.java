package com.hospital.vo;

import java.util.Date;

public class DepartmentVO {
	private String deptId;
	private String name;
	private String description;
	private String headDoctorid;
	private String phone;
	private Date createdAt;
	
	
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHeadDoctorid() {
		return headDoctorid;
	}
	public void setHeadDoctorid(String headDoctorid) {
		this.headDoctorid = headDoctorid;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	@Override
	public String toString() {
		return "DepartmentVO [deptId=" + deptId + ", name=" + name + ", description=" + description + ", headDoctorid="
				+ headDoctorid + ", phone=" + phone + ", createdAt=" + createdAt + "]";
	}
	
	
}
