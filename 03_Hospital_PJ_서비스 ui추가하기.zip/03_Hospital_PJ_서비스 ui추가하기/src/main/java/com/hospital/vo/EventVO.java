package com.hospital.vo;

import java.util.Date;

public class EventVO {

    private int eventId;            // 이벤트 ID
    private String title;           // 제목
    private String description;     // 설명 (CLOB)
    private Date eventDate;         // 행사 날짜
    private String location;        // 장소
    private String createdBy;       // 작성자 ID
    private Date createdAt;         // 생성일
    private Date updatedAt;         // 수정일
    private String status;          // 상태 (게시 등)
    private int viewCount;      	// 조회수
    private String thumbnailPath;   // 썸네일 경로
    private String imagePath;       // 이미지 경로
    private String category;		// 카테고리
    private String speaker; 		// 강사명
    private Date startDate;			// 시작일
    private Date endDate;			// 종료일
    private String timeInfo;		// 시간
    private String contact;			// 연락처
    private String reporter;
    private String source;
 
    // 날짜 포맷용 문자열 필드
    private String eventDateStr;
    private String createdAtStr;
    private String startDateStr;
    private String endDateStr;


    // 기본 생성자
    public EventVO() {}

    // Getter & Setter
    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getViewCount() {
        return viewCount;
    }

    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }

    public String getThumbnailPath() {
        return thumbnailPath;
    }

    public void setThumbnailPath(String thumbnailPath) {
        this.thumbnailPath = thumbnailPath;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}
	
	public String getSpeaker() {
	    return speaker;
	}

	public void setSpeaker(String speaker) {
	    this.speaker = speaker;
	}
	
	public Date getStartDate() {
	    return startDate;
	}

	public void setStartDate(Date startDate) {
	    this.startDate = startDate;
	}

	public Date getEndDate() {
	    return endDate;
	}

	public void setEndDate(Date endDate) {
	    this.endDate = endDate;
	}

	public String getTimeInfo() {
	    return timeInfo;
	}

	public void setTimeInfo(String timeInfo) {
	    this.timeInfo = timeInfo;
	}

	public String getContact() {
	    return contact;
	}

	public void setContact(String contact) {
	    this.contact = contact;
	}
	public String getReporter() {
	    return reporter;
	}

	public void setReporter(String reporter) {
	    this.reporter = reporter;
	}

	public String getSource() {
	    return source;
	}

	public void setSource(String source) {
	    this.source = source;
	}
	
	public String getEventDateStr() {
	    return eventDateStr;
	}

	public void setEventDateStr(String eventDateStr) {
	    this.eventDateStr = eventDateStr;
	}

	public String getCreatedAtStr() {
	    return createdAtStr;
	}

	public void setCreatedAtStr(String createdAtStr) {
	    this.createdAtStr = createdAtStr;
	}
	
	public String getStartDateStr() { return startDateStr; }
	public void setStartDateStr(String startDateStr) { this.startDateStr = startDateStr; }

	public String getEndDateStr() { return endDateStr; }
	public void setEndDateStr(String endDateStr) { this.endDateStr = endDateStr; }


	@Override
	public String toString() {
		return "EventVO [eventId=" + eventId + ", title=" + title + ", description=" + description + ", eventDate="
				+ eventDate + ", location=" + location + ", createdBy=" + createdBy + ", createdAt=" + createdAt
				+ ", updatedAt=" + updatedAt + ", status=" + status + ", viewCount=" + viewCount + ", thumbnailPath="
				+ thumbnailPath + ", imagePath=" + imagePath 
				+ ", category=" + category + ", speaker=" + speaker + "]";
	}
    
    
    
}

