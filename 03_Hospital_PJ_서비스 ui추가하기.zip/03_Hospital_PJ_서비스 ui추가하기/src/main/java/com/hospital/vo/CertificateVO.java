package com.hospital.vo;

import java.util.Date;

public class CertificateVO {
	private  int certificateId;
	private  int intpatientNo;
	private  int intrecordId;
	private String type;
	private String content;
	private  Date issuedAt;
	private String issuedBy;
	private String method;
	private String requestMethod;
	private String status;
	private  Date viewedAt;
	public int getCertificateId() {
		return certificateId;
	}
	public void setCertificateId(int certificateId) {
		this.certificateId = certificateId;
	}
	public int getIntpatientNo() {
		return intpatientNo;
	}
	public void setIntpatientNo(int intpatientNo) {
		this.intpatientNo = intpatientNo;
	}
	public int getIntrecordId() {
		return intrecordId;
	}
	public void setIntrecordId(int intrecordId) {
		this.intrecordId = intrecordId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getIssuedAt() {
		return issuedAt;
	}
	public void setIssuedAt(Date issuedAt) {
		this.issuedAt = issuedAt;
	}
	public String getIssuedBy() {
		return issuedBy;
	}
	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getRequestMethod() {
		return requestMethod;
	}
	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getViewedAt() {
		return viewedAt;
	}
	public void setViewedAt(Date viewedAt) {
		this.viewedAt = viewedAt;
	}
	@Override
	public String toString() {
		return "CertificateVO [certificateId=" + certificateId + ", intpatientNo=" + intpatientNo + ", intrecordId="
				+ intrecordId + ", type=" + type + ", content=" + content + ", issuedAt=" + issuedAt + ", issuedBy="
				+ issuedBy + ", method=" + method + ", requestMethod=" + requestMethod + ", status=" + status
				+ ", viewedAt=" + viewedAt + "]";
	}
	
	
	
}
