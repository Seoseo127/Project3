package com.hospital.vo;

import java.util.Date;

public class MedicalRecordVO {
	private int recordId;
	private int reservationId;
	private String doctorId;
	private String diagnosis;
	private String treatment;
	private String prescription;

	public int getPatientNo() {
		return patientNo;
	}

	public void setPatientNo(int patientNo) {
		this.patientNo = patientNo;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	private Date recordDate;
	private String doctorName; // 의사 이름 (users 테이블 조인)
	private String departmentName; // 진료과 이름 (departments 테이블 조인)
	private int patientNo; // 환자번호 join
	private String patientName; // 환자이름 join

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public int getRecordId() {
		return recordId;
	}

	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}

	public int getReservationId() {
		return reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	public String getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getTreatment() {
		return treatment;
	}

	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}

	public String getPrescription() {
		return prescription;
	}

	public void setPrescription(String prescription) {
		this.prescription = prescription;
	}

	public Date getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(Date recordDate) {
		this.recordDate = recordDate;
	}

	@Override
	public String toString() {
		return "RecordVO{" + "recordId=" + recordId + ", reservationId=" + reservationId + ", doctorId='" + doctorId
				+ '\'' + ", diagnosis='" + diagnosis + '\'' + ", treatment='" + treatment + '\'' + ", prescription='"
				+ prescription + '\'' + ", recordDate=" + recordDate + '}';
	}
}
