package com.hospital.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.hospital.vo.ReservationVO;

@Mapper
public interface ReservationDAO {
	List<ReservationVO> getReservationsByPatientNo(int patientNo);

	int insertReservation(ReservationVO vo);

	int updateReservationStatus(@Param("reservationId") int reservationId, @Param("status") String status);

	int countTodayReservations();
}
