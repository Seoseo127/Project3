package com.hospital.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.hospital.vo.AdminVO;
import com.hospital.vo.FeedbackVO;
import com.hospital.vo.MedicalNoticeVO;
import com.hospital.vo.ReservationVO;
import com.hospital.vo.UserVO;

@Mapper
public interface AdminDAO {
	AdminVO login(@Param("adminId") String adminId, @Param("password") String password);

	void insertAdmin(AdminVO vo);

	int countAdmittedPatients();

	int countUnreadNotices();

	int countTotalReferrals();

	int countRepliedReferrals();

	int countFeedbackByStatus(String status);

	List<FeedbackVO> getRecentFeedbacksByStatus(String status);

	List<ReservationVO> getReservationStatsLast7Days();

	void updateUserRole(@Param("userId") String userId, @Param("role") String role);

	List<UserVO> getAllUsers();

	List<ReservationVO> getReservationSummaryByDateRange();

	List<ReservationVO> getReservationsByDate(@Param("date") String date);

}
