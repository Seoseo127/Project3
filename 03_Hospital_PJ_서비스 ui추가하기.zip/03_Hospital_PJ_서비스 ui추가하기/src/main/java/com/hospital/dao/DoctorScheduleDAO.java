package com.hospital.dao;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.hospital.vo.DoctorScheduleVO;

@Mapper
public interface DoctorScheduleDAO {
	List<DoctorScheduleVO> getSchedulesByDoctorId(@Param("doctorId") String doctorId);

	void deleteSchedule(@Param("scheduleId") int scheduleId);

	DoctorScheduleVO getScheduleById(@Param("scheduleId") int scheduleId);

	void updateSchedule(DoctorScheduleVO vo);

	void insertSchedule(DoctorScheduleVO vo); // 필요 시
}
