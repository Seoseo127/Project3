package com.hospital.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.hospital.vo.DepartmentVO;

@Mapper
public interface DepartmentDAO {
	List<DepartmentVO> getAllDepartments(); // 진료과 전체 조회

	DepartmentVO getDepartmentById(String deptId); // 상세 조회
}
