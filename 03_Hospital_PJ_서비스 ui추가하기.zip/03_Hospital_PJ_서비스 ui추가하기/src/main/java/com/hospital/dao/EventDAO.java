package com.hospital.dao;

import com.hospital.vo.EventVO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class EventDAO {

	@Autowired
	private SqlSession sqlSession;

	public List<EventVO> selectEventsByCategoryInfo(String category) {
		return sqlSession.selectList("eventMapper.selectEventsByCategoryInfo", category);
	}

	public EventVO selectEventByIdInfo(int eventId) {
		return sqlSession.selectOne("eventMapper.selectEventByIdInfo", eventId);
	}

	public void insertEventInfo(EventVO eventVO) {
		sqlSession.insert("eventMapper.insertEventInfo", eventVO);
	}

	public void updateEventInfo(EventVO eventVO) {
		sqlSession.update("eventMapper.updateEventInfo", eventVO);
	}

	public void deleteEventInfo(int eventId) {
		sqlSession.delete("eventMapper.deleteEventInfo", eventId);
	}

	public List<EventVO> selectGeneralInfoEventsInfo() {
		return sqlSession.selectList("eventMapper.selectGeneralInfoEventsInfo");
	}

	// ✅ 페이징 카운트
	public int countEventsByCategory(String category) {
		return sqlSession.selectOne("eventMapper.countEventsByCategory", category);
	}

	public void updateViewCount(int eventId) {
		sqlSession.update("eventMapper.updateViewCount", eventId);
	}

	// ✅ 페이징 목록
	public List<EventVO> selectEventsByCategoryWithPaging(String category, int offset, int pageSize) {
		Map<String, Object> params = new HashMap<>();
		params.put("category", category);
		params.put("offset", offset);
		params.put("pageSize", pageSize);
		return sqlSession.selectList("eventMapper.selectEventsByCategoryWithPaging", params);
	}

	public List<EventVO> selectFilteredEvents(List<String> categories, int offset, int limit) {
		Map<String, Object> params = new HashMap<>();
		params.put("categories", categories);
		params.put("offset", offset);
		params.put("limit", limit);
		return sqlSession.selectList("eventMapper.selectFilteredEvents", params);
	}

	// DAO
	public void insertLectureEvent(EventVO event) {
		sqlSession.insert("eventMapper.insertLectureEvent", event);
	}

}
