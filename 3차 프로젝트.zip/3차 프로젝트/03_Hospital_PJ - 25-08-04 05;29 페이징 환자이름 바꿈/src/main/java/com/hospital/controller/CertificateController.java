package com.hospital.controller;

import com.hospital.service.CertificateService;
import com.hospital.service.PatientService;
import com.hospital.vo.CertificateVO;
import com.hospital.vo.MedicalRecordVO;
import com.hospital.vo.PagingVO;
import com.hospital.vo.PatientVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/certificates")
public class CertificateController {

    @Autowired
    private CertificateService certificatesService;

    @Autowired
    private PatientService patientService;
    
    @Autowired
    private CertificateService certificateService;

    // 헬퍼 메서드: URL 인코딩 (리다이렉트 시 한글 깨짐 방지)
    private String encodeUrl(String url) {
        try {
            return URLEncoder.encode(url, StandardCharsets.UTF_8.toString()).replaceAll("\\+", "%20");
        } catch (Exception e) {
            return url;
        }
    }

 // RQ-603: 증명서 발급 신청 폼 페이지
    @GetMapping("/request.do")
    public String showRequestForm(Model model, HttpSession session, RedirectAttributes redirectAttributes) {
        String loggedInUserId = (String) session.getAttribute("loggedInUserId");
        String loggedInRole = (String) session.getAttribute("loggedInRole");

        if (loggedInUserId == null || !"patient".equals(loggedInRole)) {
            redirectAttributes.addFlashAttribute("error", "증명서 발급 신청은 로그인한 환자만 이용 가능합니다.");
            String currentUrl = "/certificates/request.do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        PatientVO loggedInPatient = patientService.getPatientByUserId(loggedInUserId);
        if (loggedInPatient == null) {
            redirectAttributes.addFlashAttribute("error", "환자 정보를 찾을 수 없습니다. 다시 로그인 해주세요.");
            session.invalidate();
            String currentUrl = "/certificates/request.do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        // --- 이 부분에 진료 기록을 가져오는 로직을 추가해야 합니다 ---
        // 1. 환자 번호(patientNo)를 가져옵니다.
        int patientNo = loggedInPatient.getPatientNo();

        // 2. 서비스 메서드를 호출하여 해당 환자의 진료 기록 목록을 가져옵니다.
        List<MedicalRecordVO> medicalRecords = certificatesService.getMedicalRecordsByPatientNo(patientNo);
        
        // 3. 가져온 목록을 "medicalRecords"라는 이름으로 Model에 담아 뷰로 전달합니다.
        model.addAttribute("medicalRecords", medicalRecords);
        // -------------------------------------------------------------

        CertificateVO certificateVO = new CertificateVO();
        certificateVO.setPatientNo(patientNo);

        model.addAttribute("certificateVO", certificateVO);
        model.addAttribute("loggedInPatientName", loggedInPatient.getPatientName());
        model.addAttribute("loggedInPatientNo", patientNo);
        model.addAttribute("pageTitle", "증명서 발급 신청");
        return "certificates/certificateRequestForm";
    }
    // RQ-603: 증명서 발급 신청 처리
    @PostMapping("/request.do")
    public String submitCertificateRequest(@ModelAttribute CertificateVO certificateVO,
                                           RedirectAttributes redirectAttributes,
                                           HttpSession session) {
        String loggedInUserId = (String) session.getAttribute("loggedInUserId");
        String loggedInRole = (String) session.getAttribute("loggedInRole");

        if (loggedInUserId == null || !"patient".equals(loggedInRole)) {
            redirectAttributes.addFlashAttribute("error", "잘못된 접근입니다. 로그인 후 이용해주세요.");
            String currentUrl = "/certificates/request.do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        PatientVO loggedInPatient = patientService.getPatientByUserId(loggedInUserId);
        if (loggedInPatient == null) {
            redirectAttributes.addFlashAttribute("error", "환자 정보를 찾을 수 없습니다. 다시 로그인 해주세요.");
            session.invalidate();
            String currentUrl = "/certificates/request.do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        if (loggedInPatient.getPatientNo() != certificateVO.getPatientNo()) {
            redirectAttributes.addFlashAttribute("error", "로그인 정보와 환자 번호가 일치하지 않습니다. 올바른 환자 번호를 입력해주세요.");
            redirectAttributes.addFlashAttribute("certificateVO", certificateVO);
            return "redirect:/certificates/request.do";
        }

        try {
            CertificateVO result = certificatesService.requestCertificate(certificateVO);
            
            // 수정된 부분: 환자 이름을 가져와 메시지에 포함시킵니다.
            String patientName = loggedInPatient.getPatientName();
            String message = patientName + "님, 증명서 발급이 성공적으로 완료되었습니다. 신청번호: " + result.getCertificateId();
            
            redirectAttributes.addFlashAttribute("message", message);
            return "redirect:/certificates/history.do?patientNo=" + result.getPatientNo();

        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "증명서 발급 신청 실패: " + e.getMessage());
            redirectAttributes.addFlashAttribute("certificateVO", certificateVO);
            return "redirect:/certificates/request.do";
        }
    }

    // RQ-605: 서류 발급 이력 조회 페이지 (페이징 추가)
    @GetMapping("/history.do")
    public String showCertificateHistory(
            @RequestParam(required = false, defaultValue = "1") int page, // 현재 페이지 번호
            @RequestParam(required = false, defaultValue = "15") int pageSize, // 페이지당 항목 수
            Model model,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String loggedInUserId = (String) session.getAttribute("loggedInUserId");
        String loggedInRole = (String) session.getAttribute("loggedInRole");

        if (loggedInUserId == null || !"patient".equals(loggedInRole)) {
            redirectAttributes.addFlashAttribute("error", "증명서 발급 이력은 로그인한 환자만 이용 가능합니다.");
            String currentUrl = "/certificates/history.do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        PatientVO loggedInPatient = patientService.getPatientByUserId(loggedInUserId);
        if (loggedInPatient == null) {
            redirectAttributes.addFlashAttribute("error", "환자 정보를 찾을 수 없습니다. 다시 로그인 해주세요.");
            session.invalidate();
            String currentUrl = "/certificates/history.do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        int actualPatientNo = loggedInPatient.getPatientNo();

        // 1. 전체 항목 수를 조회합니다.
        int totalCount = certificatesService.getCertificateHistoryCount(actualPatientNo);

        // 2. 페이징 정보 객체를 생성합니다.
        PagingVO pageInfo = new PagingVO(totalCount, page, pageSize, 5); // totalCount, currentPage, pageSize, pageBlockSize

        // 3. 페이지 정보에 따라 데이터베이스에서 해당 페이지의 데이터만 가져옵니다.
        List<CertificateVO> history = certificatesService.getCertificateHistoryByPage(actualPatientNo, pageInfo.getStartIndex(), pageSize);

        // 4. 모델에 페이징 정보와 데이터를 담아 JSP로 전달합니다.
        model.addAttribute("searchPatientNo", actualPatientNo);
        model.addAttribute("certificates", history);
        model.addAttribute("page", pageInfo); // 페이징 정보 객체
        model.addAttribute("pageTitle", "서류 발급 이력 조회");

        
     // 수정된 부분: 로그인한 환자 이름을 모델에 추가
        model.addAttribute("loggedInPatientName", loggedInPatient.getPatientName());
       
        return "certificates/certificateHistory";
    }

    // 증명서 상세 조회 페이지 (관리자 또는 환자 열람용)
    @GetMapping("/detail/{certificateId}.do")
    public String showCertificateDetail(@PathVariable("certificateId") int certificateId, Model model,
                                        HttpSession session, RedirectAttributes redirectAttributes) {
        String loggedInUserId = (String) session.getAttribute("loggedInUserId");
        String loggedInRole = (String) session.getAttribute("loggedInRole");

        if (loggedInUserId == null) {
            redirectAttributes.addFlashAttribute("error", "로그인 후 이용 가능합니다.");
            String currentUrl = "/certificates/detail/" + certificateId + ".do";
            return "redirect:/patient/selectForm.do?returnUrl=" + encodeUrl(currentUrl);
        }

        CertificateVO certificate = certificatesService.getCertificateDetail(certificateId);
        if (certificate == null) {
            redirectAttributes.addFlashAttribute("error", "존재하지 않는 증명서입니다.");
            return "redirect:/certificates/history.do";
        }

        boolean hasAdminRole = "admin".equals(loggedInRole) || "coop".equals(loggedInRole) || "doctor".equals(loggedInRole) || "nurse".equals(loggedInRole);

        if (!hasAdminRole) {
            PatientVO loggedInPatient = patientService.getPatientByUserId(loggedInUserId);
            if (loggedInPatient == null || loggedInPatient.getPatientNo() != certificate.getPatientNo()) {
                redirectAttributes.addFlashAttribute("error", "다른 환자의 증명서를 조회할 수 없습니다.");
                return "redirect:/certificates/history.do?patientNo=" + (loggedInPatient != null ? loggedInPatient.getPatientNo() : "");
            }
        }

        if (!"발급완료".equals(certificate.getStatus())) {
            redirectAttributes.addFlashAttribute("error", "해당 증명서는 아직 발급 완료 상태가 아닙니다.");
            if (!hasAdminRole) {
                PatientVO loggedInPatient = patientService.getPatientByUserId(loggedInUserId);
                return "redirect:/certificates/history.do?patientNo=" + (loggedInPatient != null ? loggedInPatient.getPatientNo() : "");
            } else {
                return "redirect:/admin/certificates/list.do";
            }
        }

        // 증명서가 발급완료 상태이고, viewedAt이 아직 기록되지 않았다면 현재 시간으로 업데이트
        if ("발급완료".equals(certificate.getStatus()) && certificate.getViewedAt() == null) {
            certificatesService.updateViewedAt(certificate.getCertificateId(), new Date());
            // 업데이트 후, 현재 model의 certificate 객체에도 반영 (JSP에서 바로 보이도록)
            certificate.setViewedAt(new Date());
        }

        model.addAttribute("certificate", certificate);
        model.addAttribute("pageTitle", "증명서 상세 조회");
        return "certificates/certificateDetail";
    }

    // 증명서 PDF 다운로드 (실시간 PDF 생성 방식)
    @GetMapping("/download.do")
    public ResponseEntity<byte[]> downloadCertificate(@RequestParam("certificateId") int certificateId,
                                                      HttpSession session) {
        System.out.println("다운로드 요청 시작: certificateId = " + certificateId);
        String loggedInUserId = (String) session.getAttribute("loggedInUserId");
        String loggedInRole = (String) session.getAttribute("loggedInRole");

        if (loggedInUserId == null) {
            System.out.println("로그인되지 않은 사용자. 403 반환.");
            return ResponseEntity.status(403).body(null);
        }

        CertificateVO certificate = certificatesService.getCertificateDetail(certificateId);
        System.out.println("CertificateVO 조회 완료. certificateId: " + (certificate != null ? certificate.getCertificateId() : "null"));

        if (certificate == null) {
            System.out.println("Certificate not found. 404 반환.");
            return ResponseEntity.notFound().build();
        }

        boolean hasAdminRole = "admin".equals(loggedInRole) || "coop".equals(loggedInRole) || "doctor".equals(loggedInRole) || "nurse".equals(loggedInRole);

        if (!hasAdminRole) {
            PatientVO loggedInPatient = patientService.getPatientByUserId(loggedInUserId);
            if (loggedInPatient == null || loggedInPatient.getPatientNo() != certificate.getPatientNo()) {
                System.out.println("권한 없음: 다른 환자의 증명서 조회 시도. 403 반환.");
                return ResponseEntity.status(403).body(null);
            }
        }

        if (!"발급완료".equals(certificate.getStatus())) {
            System.out.println("증명서 상태 '발급완료' 아님: " + certificate.getStatus() + ". 403 반환.");
            return ResponseEntity.status(403).body(null);
        }

        try {
            System.out.println("generateCertificatePdf 서비스 호출 시도 중...");
            byte[] pdfBytes = certificatesService.generateCertificatePdf(certificateId);
            System.out.println("PDF 바이트 배열 생성 완료. 크기: " + (pdfBytes != null ? pdfBytes.length : "null"));

            // viewedAt 업데이트 (다운로드 시에도 열람으로 간주)
            // 이 부분을 다시 활성화합니다.
            if (certificate.getViewedAt() == null) {
                System.out.println("viewedAt 업데이트 시도 중...");
                certificatesService.updateViewedAt(certificate.getCertificateId(), new Date());
                System.out.println("viewedAt 업데이트 완료.");
            }

            String fileName = certificate.getType() + "_" + certificate.getCertificateId() + ".pdf";
            String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8.toString()).replaceAll("\\+", "%20");
            System.out.println("파일 이름 인코딩 완료: " + encodedFileName);

            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_PDF)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFileName + "\"")
                    .body(pdfBytes);

        } catch (IllegalArgumentException | IllegalStateException e) {
            System.err.println("PDF 생성 중 오류 발생 (서비스 계층): " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            System.err.println("예기치 않은 PDF 생성 오류 발생 (최상위): " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("PDF 생성 중 알 수 없는 오류가 발생했습니다.".getBytes(StandardCharsets.UTF_8));
        }
    }
    
 

    @GetMapping("/doctor/writeForm.do")
    public String showDoctorWriteForm(@RequestParam("certificateId") int certificateId, Model model) {
        CertificateVO certificate = certificatesService.getCertificateById(certificateId);
        model.addAttribute("certificate", certificate);
        return "doctor/doctor_Pending_Certificates";
    }

    @PostMapping("/saveCertificate.do")
    public String saveDoctorCertificate(@ModelAttribute CertificateVO certificateVO,
                                        RedirectAttributes redirectAttributes) {
        try {
            certificatesService.completeCertificate(certificateVO);
            redirectAttributes.addFlashAttribute("message", "소견서가 성공적으로 저장되었습니다.");
            return "redirect:/certificates/doctor/pending.do";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "저장 실패: " + e.getMessage());
            return "redirect:/certificates/doctor/writeForm.do?certificateId=" + certificateVO.getCertificateId();
        }
        
        
    }
    // 수정 페이지로 이동하는 메소드
    @GetMapping("/doctor/editForm.do")
    public String showEditForm(@RequestParam("certificateId") int certificateId, Model model) {
        // 주입받은 certificateService 인스턴스를 사용해서 메소드를 호출합니다.
        CertificateVO certificate = certificateService.getCertificateById(certificateId);

        model.addAttribute("certificate", certificate);

        return "doctor/doctor_pending_editForm";
    }



@GetMapping("/doctor/pending.do")
public String showDoctorCertificates(@RequestParam(defaultValue = "1") int page, Model model) {
    int pageSize = 15; // 한 페이지에 표시할 항목 수
    int totalCount = certificateService.getCertificateCount(); // 전체 게시물 수
    
    // 페이징 계산
    int totalPages = (int) Math.ceil((double) totalCount / pageSize);
    int offset = (page - 1) * pageSize;
    
    // 현재 페이지의 목록 가져오기
    List<CertificateVO> certificates = certificateService.getPaginatedCertificates(offset, pageSize);
    
    model.addAttribute("certificates", certificates);
    model.addAttribute("currentPage", page);
    model.addAttribute("totalPages", totalPages);
    
    return "doctor/doctor_pending_list";
	}
}
