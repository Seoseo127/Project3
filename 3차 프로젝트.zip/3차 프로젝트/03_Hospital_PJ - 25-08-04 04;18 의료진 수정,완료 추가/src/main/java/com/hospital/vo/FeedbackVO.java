package com.hospital.vo;



import java.util.Date;

public class FeedbackVO {
    
    private int feedbackId;        // 피드백 ID (기본키)
    private String patientUserId;   // 환자 사용자 ID (외래키)
    private String category;        // 피드백 카테고리 (예: 진료, 서비스 등)
    private String content;         // 피드백 내용
    private String reply;           // 관리자/의료진의 답변
    private String repliedBy;       // 답변 작성자 ID
    private Date repliedAt;         // 답변 날짜
    private String status;          // 상태 (접수, 처리중, 완료 등)
    private Date createdAt;         // 피드백 작성일

    // 기본 생성자
    public FeedbackVO() {}

    // Getter & Setter
    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getPatientUserId() {
        return patientUserId;
    }

    public void setPatientUserId(String patientUserId) {
        this.patientUserId = patientUserId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public String getRepliedBy() {
        return repliedBy;
    }

    public void setRepliedBy(String repliedBy) {
        this.repliedBy = repliedBy;
    }

    public Date getRepliedAt() {
        return repliedAt;
    }

    public void setRepliedAt(Date repliedAt) {
        this.repliedAt = repliedAt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    // toString()
    @Override
    public String toString() {
        return "FeedbackDTO{" +
                "feedbackId=" + feedbackId +
                ", patientUserId='" + patientUserId + '\'' +
                ", category='" + category + '\'' +
                ", content='" + content + '\'' +
                ", reply='" + reply + '\'' +
                ", repliedBy='" + repliedBy + '\'' +
                ", repliedAt=" + repliedAt +
                ", status='" + status + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
