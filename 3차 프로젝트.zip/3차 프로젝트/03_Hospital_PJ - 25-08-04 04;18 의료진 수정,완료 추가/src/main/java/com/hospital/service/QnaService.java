package com.hospital.service;

public class QnaService {

}
