package com.hospital.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import com.hospital.dao.PatientDAO;
import com.hospital.dao.UserDAO;
import com.hospital.service.PatientService;
import com.hospital.vo.PatientVO;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientDAO patientDAO;

	@Autowired
	private UserDAO userDAO; // users 테이블도 검사하기 위해 추가

	@Override
	public boolean registerPatient(PatientVO vo) throws DuplicateKeyException {
		try {
			// [1] ID 중복 체크
			if (patientDAO.existsByUserId(vo.getPatientUserId()) > 0
					|| userDAO.existsByUserId(vo.getPatientUserId()) > 0) {
				throw new DuplicateKeyException("이미 사용 중인 아이디입니다.");
			}

			// [2] 주민등록번호 중복 체크
			if (patientDAO.existsByRrn(vo.getPatientRrn()) > 0 || userDAO.existsByRrn(vo.getPatientRrn()) > 0) {
				throw new DuplicateKeyException("이미 등록된 주민등록번호입니다.");
			}

			// [3] 이메일 중복 체크
			if (patientDAO.existsByEmail(vo.getPatientEmail()) > 0 || userDAO.existsByEmail(vo.getPatientEmail()) > 0) {
				throw new DuplicateKeyException("이미 등록된 이메일입니다.");
			}

			// [4] 등록 시도
			return patientDAO.insertPatient(vo) > 0;

		} catch (DataIntegrityViolationException e) {
			throw new DuplicateKeyException("회원가입 중 알 수 없는 오류가 발생했습니다.");
		}
	}

	@Override
	public PatientVO login(PatientVO vo) {
		return patientDAO.login(vo);
	}

	// 관리자
	@Override
	public List<PatientVO> getAllPatients() {
		return patientDAO.getAllPatients();
	}

	@Override
	public List<PatientVO> searchPatients(String keyword) {
		return patientDAO.searchPatients(keyword);
	}

	@Override
	public PatientVO getPatientByNo(int patientNo) {
		return patientDAO.getPatientByNo(patientNo);
	}

	@Override
	public void deletePatient(int patientNo) {
		patientDAO.deletePatientByNo(patientNo);
	}

	@Override
	public void logdeletePatient(String patientUserId) {
		patientDAO.deletePatientByUserId(patientUserId);
	}

	@Override
	public void insertSocialPatient(PatientVO vo) {
		System.out.println("🟢 카카오 회원가입 시도: " + vo.getPatientEmail());

		// 중복 체크 필요
		if (patientDAO.existsByEmail(vo.getPatientEmail()) > 0) {
			System.out.println("⚠ 이미 가입된 이메일입니다: " + vo.getPatientEmail());
			return; // 중복이면 삽입 안함
		}

		patientDAO.insertSocialPatient(vo);
		System.out.println("✅ 소셜 환자 등록 완료: " + vo.getPatientUserId());
	}

	@Override
	public PatientVO findPatientByEmail(String email) {
		return userDAO.findPatientByEmail(email);
	}

	// ★★★ 이 부분을 추가 또는 수정해야 합니다! ★★★
	@Override
	public PatientVO getPatientByUserId(String patientUserId) {
		return patientDAO.selectPatientByUserId(patientUserId);
	}
}
