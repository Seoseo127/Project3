package com.hospital.mapper;

public interface NotificationMapper {

}
