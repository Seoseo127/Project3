package com.hospital.mapper;

public interface referralMapper {

}
