package com.hospital.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.hospital.service.UserService;
import com.hospital.vo.DepartmentVO;
import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.UserVO;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping("/loginForm.do")
	public String loginForm() {
		return "user/user_login"; // ViewResolver 기준 /WEB-INF/jsp/user/user_login.jsp
	}

	@GetMapping("/signupForm.do")
	public String signupForm(Model model) {
		List<PartnerHospitalVO> hospitalList = userService.getAllHospitals();
		List<DepartmentVO> deptList = userService.getAllDepartments();

		model.addAttribute("hospitalList", hospitalList);
		model.addAttribute("deptList", deptList);

		return "user/user_signup";
	}

	@PostMapping("/login.do")
	public String login(@ModelAttribute UserVO vo, HttpSession session) {
		UserVO loginUser = userService.login(vo);

		if (loginUser != null) {
			session.setAttribute("loginUser", loginUser);

			// 역할별 메인페이지 분기
			if ("admin".equals(loginUser.getRole())) {
				return "redirect:/admin/admin_main.jsp";
			} else if ("doctor".equals(loginUser.getRole())) {
				return "doctor/doctor_main";
			} else if ("nurse".equals(loginUser.getRole())) {
				return "redirect:/nurse/nurse_main.jsp";
			} else if ("coop".equals(loginUser.getRole())) {
				return "redirect:/coop/coop_main.jsp";
			} else {
				return "redirect:/common/login_selector.jsp"; // 예외 처리
			}

		} else {
			session.setAttribute("loginError", "아이디 또는 비밀번호가 잘못되었습니다.");
			return "redirect:/user/loginForm.do";
		}
	}

	@PostMapping("/signup.do")
	public String signup(@ModelAttribute UserVO vo, HttpSession session) {

		// 의사/간호사: 본원(1번 병원), 진료과 선택
		if ("doctor".equals(vo.getRole())) {
			vo.setHospitalId(1); // 본원
			// 진료과는 선택값 그대로 사용
		} else if ("nurse".equals(vo.getRole())) {
			vo.setHospitalId(1);
			vo.setDeptId("000"); // 진료과 없음 처리
		} else {
			// coop(협력기관): 병원 선택값 사용
			vo.setDeptId("000"); // 진료과 없음
		}

		boolean success = userService.insertUser(vo);

		if (success) {
			session.setAttribute("signupSuccess", "회원가입이 완료되었습니다.");
			// 회원가입 후 로그인 셀렉터로 이동 (로그인 버튼 눌렀을 때와 동일)
			return "redirect:/loginSelector.do";
		} else {
			session.setAttribute("signupError", "회원가입 실패. 다시 시도해주세요.");
			return "redirect:/user/signupForm.do";
		}
	}
	
	@GetMapping("/logout.do")
	public String logout(HttpSession session) {
	    session.invalidate(); // 세션 초기화
	    return "redirect:/main.do"; // 로그인 폼으로 리다이렉트
	}

}
