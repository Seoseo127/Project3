package com.hospital.service;

import java.util.List;

import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;

public interface ReferralService {
    ReferralRequestVO convertToReferralRequest(int recordId);
    List<PartnerHospitalVO> getAllPartnerHospitals();
    void insertReferralRequest(ReferralRequestVO requestVO);
    
    List<UserVO> getDoctorsByHospital(int hospitalId);
    
    

}
