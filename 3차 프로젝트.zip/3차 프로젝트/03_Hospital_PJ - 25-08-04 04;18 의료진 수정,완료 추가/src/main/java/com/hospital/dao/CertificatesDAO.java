package com.hospital.dao;

import com.hospital.vo.CertificateVO;
import com.hospital.vo.MedicalRecordVO;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.Date;
import java.util.List;

@Mapper // 또는 @Repository
public interface CertificatesDAO {

    int insertCertificate(CertificateVO certificateVO);
    List<CertificateVO> selectCertificatesByPatientNo(int patientNo);
    
    // PatientVO, MedicalRecordVO까지 포함하여 상세 정보를 가져오는 메서드
    CertificateVO selectCertificateById(int certificateId);

    int updateCertificate(CertificateVO certificate); // 관리자용 증명서 업데이트 (상태, 발급자, 내용 등)
    List<CertificateVO> getCertificatesByStatus(String status);

    // viewedAt 필드를 업데이트하는 메서드
    int updateViewedAt(@Param("certificateId") int certificateId, @Param("viewedAt") Date viewedAt);
    
    public MedicalRecordVO selectLatestMedicalRecordByPatientNo(int patientNo);

    // 증명서 발급 완료 처리를 위한 메서드 추가
    void completeCertificate(CertificateVO certificateVO);
	MedicalRecordVO selectMedicalRecordById(Integer recordId);

	// CertificatsDAO.java (DAO 인터페이스)
	public List<MedicalRecordVO> selectMedicalRecordsByPatientNo(int patientNo);
	
	// 전체 증명서 이력 개수를 조회하는 메서드
    int getCertificateHistoryCount(@Param("patientNo") int patientNo);

    // 페이지에 맞는 증명서 이력을 조회하는 메서드
    List<CertificateVO> getCertificateHistoryByPage(@Param("patientNo") int patientNo, @Param("startIndex") int startIndex, @Param("pageSize") int pageSize);

    List<CertificateVO> getAllDoctorCertificates();
    
    // 서류 ID로 서류 정보 조회
    CertificateVO getCertificateById(int certificateId);

    // 서류의 내용(진단명, 소견 등)을 업데이트
    void updateCertificateContent(CertificateVO certificateVO);

    // 서류의 상태만 업데이트
    void updateCertificateStatus(@Param("certificateId") int certificateId, @Param("status") String status);
}


