package com.hospital.dao;

public class EventDAO {

}
