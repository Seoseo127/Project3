package com.hospital.dao;

import java.util.List;

import com.hospital.vo.PartnerHospitalVO;
import com.hospital.vo.ReferralRequestVO;
import com.hospital.vo.UserVO;

public interface ReferralDAO {
    
    // ✅ 진료기록 기반 협진요청 VO 생성용
    ReferralRequestVO convertToReferralRequest(int recordId);

    // ✅ 협진 병원 전체 조회
    List<PartnerHospitalVO> getAllPartnerHospitals();

    // ✅ 협진 요청 저장
    void insertReferralRequest(ReferralRequestVO requestVO);

    // ✅ 특정 병원 소속 의사(coop) 리스트 반환
    List<UserVO> getDoctorsByHospital(int hospitalId);
}
